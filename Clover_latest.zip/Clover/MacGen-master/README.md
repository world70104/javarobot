You probably want [macserial](https://github.com/vit9696/macserial) instead.
