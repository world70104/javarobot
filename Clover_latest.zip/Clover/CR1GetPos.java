/////////////////////////////////////////////////////////////////////////
//
//                          CR1GetPos 
//
//    get the position for CRobot1
//
//  Date: 2018/09/20
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

// import files
import java.util.Scanner;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.reflect.Field;
import java.awt.event.*;
import javax.swing.*;
import java.io.*; 
import java.util.concurrent.TimeUnit;
import java.util.UUID;
import java.io.File;
import java.io.PrintStream;

public class CR1GetPos {
    // File path
    public static String mainPath = "/Users/mac/Desktop";
    public static String ccFileNamed =  "/Clover/App/CloverConfigurator.app";
    public static String posFileName = "/Clover/Position/CR1Pos.txt";
    // robot	
    Robot robot = null;
    // delay value
	static int shiftDelay = 20;
    static int endDelay = 100;
    static int appDelay = 500;

    public static int rmPosX = 0; 
    public static int rmPosY = 0; 
    public static int riPosX = 0; 
    public static int riPosY = 0; 
    public static int miPosX = 0; 
    public static int miPosY = 0; 
    public static int smPosX = 0; 
    public static int smPosY = 0; 
    public static int pncPosX = 0; 
    public static int pncPosY = 0; 
    public static int sniPosX = 0; 
    public static int sniPosY = 0; 
    public static int siPosX = 0; 
    public static int siPosY = 0; 
    public static int bsniPosX = 0; 
    public static int bsniPosY = 0; 
    public static int svmPosX = 0; 
    public static int svmPosY = 0; 
    public static int sviPosX = 0; 
    public static int sviPosY = 0; 
    public static int endPosX = 0; 
    public static int endPosY = 0; 
    public static int okPosX = 0; 
    public static int okPosY = 0; 
    // mount EFI
    public static int emPosX = 0; 
    public static int emPosY = 0; 
    // mount patition 
    public static int mpiPosX = 0; 
    public static int mpiPosY = 0;
    // open patition 
    public static int opiPosX = 0; 
    public static int opiPosY = 0; 
    // EFI folder 
    public static int efPosX = 0; 
    public static int efPosY = 0; 
    // Clover folder 
    public static int cfPosX = 0; 
    public static int cfPosY = 0; 
    // Config.plist file 
    public static int cpPosX = 0; 
    public static int cpPosY = 0; 

    ////////////////////////////   Mouse move    ////////////////////////
    public static void MouseMoveThread(  Robot _robot,  int endX, int endY,
        int numberOfIterations, long timeToSleep ) {
        int startX;
        int startY;
        int currentX;
        int currentY;
        int xAmount;
        int yAmount;
        int xAmountPerIteration;
        int yAmountPerIteration;
                    
            Robot robot =  _robot;
            Point startLocation = MouseInfo.getPointerInfo().getLocation();
            startX = startLocation.x;
            startY = startLocation.y;
            if ( endX > startX )
                xAmount = endX - startX;
            else
                xAmount = startX - endX;
            
            if ( endY > startY )
                yAmount = endY - startY;
            else
                yAmount = startY - endY;

            currentX = startX;
            currentY = startY;

            xAmountPerIteration = xAmount / numberOfIterations;
            yAmountPerIteration = yAmount / numberOfIterations;

            if( endX >= startX ) {
                if ( endY >= startY ) {
                    while ( currentX < endX &&
                            currentY < endY ) {

                        currentX += xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX < endX &&
                            currentY > endY ) {

                        currentX += xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
            else {
                if ( endY >= startY ) {
                    while ( currentX > endX &&
                            currentY < endY ) {

                        currentX -= xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX > endX &&
                            currentY > endY ) {

                        currentX -= xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
    }
    /////////////////////////////////////////////////////////////////////

    // Write the position for robot
    public static void posFileSave() {
        try (PrintWriter out = new PrintWriter( mainPath + posFileName )) {
            String textStr = Integer.toString(rmPosX);
            out.println(textStr);
            textStr = Integer.toString(rmPosY);
            out.println(textStr);
            textStr = Integer.toString(riPosX);
            out.println(textStr);
            textStr = Integer.toString(riPosY);
            out.println(textStr);
            textStr = Integer.toString(miPosX);
            out.println(textStr);
            textStr = Integer.toString(miPosY);
            out.println(textStr);
            textStr = Integer.toString(smPosX);
            out.println(textStr);
            textStr = Integer.toString(smPosY);
            out.println(textStr);
            textStr = Integer.toString(pncPosX);
            out.println(textStr);
            textStr = Integer.toString(pncPosY);
            out.println(textStr);
            textStr = Integer.toString(sniPosX);
            out.println(textStr);
            textStr = Integer.toString(sniPosY);
            out.println(textStr);
            textStr = Integer.toString(siPosX);
            out.println(textStr);
            textStr = Integer.toString(siPosY);
            out.println(textStr);
            textStr = Integer.toString(bsniPosX);
            out.println(textStr);
            textStr = Integer.toString(bsniPosY);
            out.println(textStr);
            textStr = Integer.toString(svmPosX);
            out.println(textStr);
            textStr = Integer.toString(svmPosY);
            out.println(textStr);
            textStr = Integer.toString(sviPosX);
            out.println(textStr);
            textStr = Integer.toString(sviPosY);
            out.println(textStr);
            textStr = Integer.toString(endPosX);
            out.println(textStr);
            textStr = Integer.toString(endPosY);
            out.println(textStr);
            textStr = Integer.toString(okPosX);
            out.println(textStr);
            textStr = Integer.toString(okPosY);
            out.println(textStr);
            textStr = Integer.toString(emPosX);
            out.println(textStr);
            textStr = Integer.toString(emPosY);
            out.println(textStr);
            textStr = Integer.toString(mpiPosX);
            out.println(textStr);
            textStr = Integer.toString(mpiPosY);
            out.println(textStr);
            textStr = Integer.toString(opiPosX);
            out.println(textStr);
            textStr = Integer.toString(opiPosY);
            out.println(textStr);
            // EFI folder 
            textStr = Integer.toString(efPosX);
            out.println(textStr);
            textStr = Integer.toString(efPosY);
            out.println(textStr);
            // Clover folder 
            textStr = Integer.toString(cfPosX);
            out.println(textStr);
            textStr = Integer.toString(cfPosY);
            out.println(textStr);
            // Config.plist file 
            textStr = Integer.toString(cpPosX);
            out.println(textStr);
            textStr = Integer.toString(cpPosY);
            out.println(textStr);
        }
        catch (IOException e) {
//            e.printStackTrace();
        }
    }

    // Read the position for robot
    public static void posFileRead() {
        File f = new File( mainPath + posFileName );
        if( !(f.exists() && !f.isDirectory()) ) { 
            return;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader( mainPath + posFileName ));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                rmPosX = Integer.parseInt(line);
                int i = 0;
                while (line != null) {
                    line = br.readLine();
                    if ( i == 0 ) {
                        rmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 1 ) {
                        riPosX = Integer.parseInt(line);
                    }
                    else if ( i == 2 ) {
                        riPosY = Integer.parseInt(line);
                    }
                    else if ( i == 3 ) {
                        miPosX = Integer.parseInt(line);
                    }
                    else if ( i == 4 ) {
                        miPosY = Integer.parseInt(line);
                    }
                    else if ( i == 5 ) {
                        smPosX = Integer.parseInt(line);
                    }
                    else if ( i == 6 ) {
                        smPosY = Integer.parseInt(line);
                    }
                    else if ( i == 7 ) {
                        pncPosX = Integer.parseInt(line);
                    }
                    else if ( i == 8 ) {
                        pncPosY = Integer.parseInt(line);
                    }
                    else if ( i == 9 ) {
                        sniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 10 ) {
                        sniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 11 ) {
                        siPosX = Integer.parseInt(line);
                    }
                    else if ( i == 12 ) {
                        siPosY = Integer.parseInt(line);
                    }
                    else if ( i == 13 ) {
                        bsniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 14 ) {
                        bsniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 15 ) {
                        svmPosX = Integer.parseInt(line);
                    }
                    else if ( i == 16 ) {
                        svmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 17 ) {
                        sviPosX = Integer.parseInt(line);
                    }
                    else if ( i == 18 ) {
                        sviPosY = Integer.parseInt(line);
                    }
                    else if ( i == 19 ) {
                        endPosX = Integer.parseInt(line);
                    }
                    else if ( i == 20 ) {
                        endPosY = Integer.parseInt(line);
                    }
                    else if ( i == 21 ) {
                        okPosX = Integer.parseInt(line);
                    }
                    else if ( i == 22 ) {
                        okPosY = Integer.parseInt(line);
                    }
                    else if ( i == 23 ) {
                        emPosX = Integer.parseInt(line);
                    }
                    else if ( i == 24 ) {
                        emPosY = Integer.parseInt(line);
                    }
                    else if ( i == 25 ) {
                        mpiPosX = Integer.parseInt(line);
                    }
                    else if ( i == 26 ) {
                        mpiPosY = Integer.parseInt(line);
                    }
                    else if ( i == 27 ) {
                        opiPosX = Integer.parseInt(line);
                    }
                    else if ( i == 28 ) {
                        opiPosY = Integer.parseInt(line);
                    }
                    else if ( i == 29 ) {
                        efPosX = Integer.parseInt(line);
                    }
                    else if ( i == 30 ) {
                        efPosY = Integer.parseInt(line);
                    }
                    // Clover folder
                    else if ( i == 31 ) {
                        cfPosX = Integer.parseInt(line);
                    }
                    else if ( i == 32 ) {
                        cfPosY = Integer.parseInt(line);
                    }
                    // Config.plist file
                    else if ( i == 33 ) {
                        cpPosX = Integer.parseInt(line);
                    }
                    else if ( i == 34 ) {
                        cpPosY = Integer.parseInt(line);
                    }
                    i++;
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }

    }

	public static void main(String[] args) throws Throwable {

        // execute Clover Configurator 
        try {
            Runtime runtime = Runtime.getRuntime();
            String s= "open " + mainPath + ccFileNamed;
            Process proc = runtime.exec(s);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the Clover Configurator window position (0,0)
        String code = "";
        code += "tell application \"System Events\" to tell process \"Clover Configurator\"\n";
        code += "    tell application \"Clover Configurator\" to activate\n";
        code += "    tell front window to set position to {0, 0}\n";
        code += "end tell\n";
        new AppleScript().run("move_win.as", code);
        Thread.sleep(appDelay);

        CR1GetPos mainObj = new CR1GetPos();
        // make robot
        try { 
            mainObj.robot = new Robot(); 
        }
        catch (Exception ex) { 
            ex.printStackTrace(); 
        }        

        Scanner keyboard = new Scanner(System.in);
        boolean exit = false;
        
        // If pos file, read
        posFileRead();

        while (!exit) {
            System.out.println("-------------------------");
            System.out.println("Enter command");
            // RtVariables Menu
            if ( rmPosX == 0 )
                System.out.println("u to RtVariables Menu"); 
            else {
                String str = "u to RtVariables Menu - x:";
                String add = Integer.toString(rmPosX);
                str += add;
                str += " y:";
                add = Integer.toString(rmPosY);
                str += add;
                System.out.println(str);
            }
            // ROM item
            if ( riPosX == 0 )
                System.out.println("r to ROM item"); 
            else {
                String str = "r to ROM item - x:";
                String add = Integer.toString(riPosX);
                str += add;
                str += " y:";
                add = Integer.toString(riPosY);
                str += add;
                System.out.println(str);
            }
            // MLB item
            if ( miPosX == 0 )
                System.out.println("m to MLB item"); 
            else {
                String str = "m to MLB item - x:";
                String add = Integer.toString(miPosX);
                str += add;
                str += " y:";
                add = Integer.toString(miPosY);
                str += add;
                System.out.println(str);
            }
            // SMBIOS Menu
            if ( smPosX == 0 )
                System.out.println("s to SMBIOS Menu"); 
            else {
                String str = "s to SMBIOS Menu - x:";
                String add = Integer.toString(smPosX);
                str += add;
                str += " y:";
                add = Integer.toString(smPosY);
                str += add;
                System.out.println(str);
            }
            // product name combobox
            if ( pncPosX == 0 )
                System.out.println("c to Product Name CoboBox"); 
            else {
                String str = "c to Product Name CoboBox - x:";
                String add = Integer.toString(pncPosX);
                str += add;
                str += " y:";
                add = Integer.toString(pncPosY);
                str += add;
                System.out.println(str);
            }

            // Serial Number item
            if ( sniPosX == 0 )
                System.out.println("n to Serial Number item"); 
            else {
                String str = "n to Serial Number item - x:";
                String add = Integer.toString(sniPosX);
                str += add;
                str += " y:";
                add = Integer.toString(sniPosY);
                str += add;
                System.out.println(str);
            }
            // SmUUID item
            if ( siPosX == 0 )
                System.out.println("i to SmUUID item"); 
            else {
                String str = "i to SmUUID item - x:";
                String add = Integer.toString(siPosX);
                str += add;
                str += " y:";
                add = Integer.toString(siPosY);
                str += add;
                System.out.println(str);
            }
            // Board Serial Number item
            if ( bsniPosX == 0 )
                System.out.println("b to Board Serial Number item"); 
            else {
                String str = "b to Board Serial Number item - x:";
                String add = Integer.toString(bsniPosX);
                str += add;
                str += " y:";
                add = Integer.toString(bsniPosY);
                str += add;
                System.out.println(str);
            }
            // save menu
            if ( svmPosX == 0 )
                System.out.println("v to save menu"); 
            else {
                String str = "v to save menu - x:";
                String add = Integer.toString(svmPosX);
                str += add;
                str += " y:";
                add = Integer.toString(svmPosY);
                str += add;
                System.out.println(str);
            }
            // end
            if ( endPosX == 0 )
                System.out.println("a to end"); 
            else {
                String str = "a to end - x:";
                String add = Integer.toString(endPosX);
                str += add;
                str += " y:";
                add = Integer.toString(endPosY);
                str += add;
                System.out.println(str);
            }
            // ok
            if ( okPosX == 0 )
                System.out.println("k to ok"); 
            else {
                String str = "k to ok - x:";
                String add = Integer.toString(okPosX);
                str += add;
                str += " y:";
                add = Integer.toString(okPosY);
                str += add;
                System.out.println(str);
            }
            // save item
            if ( sviPosX == 0 )
                System.out.println("z to save item"); 
            else {
                String str = "z to save item - x:";
                String add = Integer.toString(sviPosX);
                str += add;
                str += " y:";
                add = Integer.toString(sviPosY);
                str += add;
                System.out.println(str);
            }
            // Mount EFI menu
            if ( emPosX == 0 )
                System.out.println("1 to Mount EFI menu"); 
            else {
                String str = "1 to Mount EFI menu - x:";
                String add = Integer.toString(emPosX);
                str += add;
                str += " y:";
                add = Integer.toString(emPosY);
                str += add;
                System.out.println(str);
            }
            // Mount Partion item
            if ( mpiPosX == 0 )
                System.out.println("2 to Mount Partion item"); 
            else {
                String str = "2 to Mount Partion item - x:";
                String add = Integer.toString(mpiPosX);
                str += add;
                str += " y:";
                add = Integer.toString(mpiPosY);
                str += add;
                System.out.println(str);
            }
            // Open Partion item
            if ( opiPosX == 0 )
                System.out.println("3 to Open Partion item"); 
            else {
                String str = "3 to Open Partion item - x:";
                String add = Integer.toString(opiPosX);
                str += add;
                str += " y:";
                add = Integer.toString(opiPosY);
                str += add;
                System.out.println(str);
            }
            // EFI folder 
            if ( efPosX == 0 )
                System.out.println("4 to EFI folder"); 
            else {
                String str = "4 to EFI folder - x:";
                String add = Integer.toString(efPosX);
                str += add;
                str += " y:";
                add = Integer.toString(efPosY);
                str += add;
                System.out.println(str);
            }
            // Clover folder 
            if ( cfPosX == 0 )
                System.out.println("5 to Clover folder"); 
            else {
                String str = "5 to Clover folder - x:";
                String add = Integer.toString(cfPosX);
                str += add;
                str += " y:";
                add = Integer.toString(cfPosY);
                str += add;
                System.out.println(str);
            }
            // Config.plist file
            if ( cpPosX == 0 )
                System.out.println("6 to Config.plist file"); 
            else {
                String str = "6 to Config.plist file - x:";
                String add = Integer.toString(cpPosX);
                str += add;
                str += " y:";
                add = Integer.toString(cpPosY);
                str += add;
                System.out.println(str);
            }
            System.out.println("t to test"); 
            System.out.println("e to save"); 
            System.out.println("q to exit"); 
            System.out.println("-------------------------");

            String input = keyboard.nextLine();
            if(input != null) {
                // Quit
                if ("q".equals(input)) {
                    exit = true;
                } 
                // Save
                else if ("e".equals(input)) {
                    posFileSave();
                } 
                // Test
                else if ("t".equals(input)) {
//////////////////////////////    test     ///////////////////////////////////////////////
                    // Go to Mount EFI Menu
                    int endX = emPosX;
                    int endY = emPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Mount Partition
                    endX = mpiPosX;
                    endY = mpiPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Open Partition
                    endX = opiPosX;
                    endY = opiPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Set the Finder window position (0,0)
                    code = "";
                    code += "tell application \"System Events\" to tell process \"Finder\"\n";
                    code += "    tell application \"Finder\" to activate\n";
                    code += "    tell front window to set position to {0, 0}\n";
                    code += "end tell\n";
                    new AppleScript().run("move_win.as", code);
                    Thread.sleep(appDelay);

                    // Go to EFI folder
                    endX = efPosX;
                    endY = efPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Clover folder
                    endX = cfPosX;
                    endY = cfPosY;
//                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Config.plist file 
                    endX = cpPosX;
                    endY = cpPosY;
//                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);

                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Set the Clover Configurator window position (0,0)
                    code = "";
                    code += "tell application \"System Events\" to tell process \"Clover Configurator\"\n";
                    code += "    tell application \"Clover Configurator\" to activate\n";
                    code += "    tell front window to set position to {0, 0}\n";
                    code += "end tell\n";
                    new AppleScript().run("move_win.as", code);
                    Thread.sleep(appDelay);

                    // Go to RtVariables Menu
                    endX = rmPosX;
                    endY = rmPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to ROM
                    endX = riPosX;
                    endY = riPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to MLB
                    endX = miPosX;
                    endY = miPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to SMBIOS
                    endX = smPosX;
                    endY = smPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Product name combobox
                    endX = pncPosX;
                    endY = pncPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);

                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);
                    for ( int j = 0; j < 5; j++ ) {
                        // key Enter                         
                        mainObj.robot.keyPress( KeyEvent.VK_UP );
                        mainObj.robot.keyRelease( KeyEvent.VK_UP );
                        mainObj.robot.delay(endDelay);    
                    }
                    // key Enter                         
                    mainObj.robot.keyPress( KeyEvent.VK_ENTER );
                    mainObj.robot.keyRelease( KeyEvent.VK_ENTER );
                    mainObj.robot.delay(endDelay);    

                    // Go to Serial Number
                    endX = sniPosX;
                    endY = sniPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(2);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to SmUUID
                    endX = siPosX;
                    endY = siPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);

                    // Go to Board SN
                    endX = bsniPosX;
                    endY = bsniPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);

                    // Go to Save menu
                    endX = svmPosX;
                    endY = svmPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to Save item
                    endX = sviPosX;
                    endY = sviPosY;
//                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to end
                    endX = endPosX;
                    endY = endPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

                    // Go to ok
                    endX = okPosX;
                    endY = okPosY;
                    mainObj.MouseMoveThread( mainObj.robot, endX, endY, 100, 5 );
                    mainObj.robot.mouseMove( endX, endY );
                    mainObj.robot.delay(endDelay);
                    // first click
                    mainObj.robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
                    mainObj.robot.delay(endDelay);

//////////////////////////////////////////////////////////////////////////////////////////

                }
                    // RtVariables Menu
                else if ("u".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    rmPosX = startLocation.x;
                    rmPosY = startLocation.y;
                } 
                // ROM item
                else if ("r".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    riPosX = startLocation.x;
                    riPosY = startLocation.y;
                } 
                // MLB item
                else if ("m".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    miPosX = startLocation.x;
                    miPosY = startLocation.y;
                } 
                // SMBIOS Menu
                else if ("s".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    smPosX = startLocation.x;
                    smPosY = startLocation.y;
                } 
                // product name combobox
                else if ("c".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    pncPosX = startLocation.x;
                    pncPosY = startLocation.y;
                } 
                // Serial Number item
                else if ("n".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    sniPosX = startLocation.x;
                    sniPosY = startLocation.y;
                } 
                // SmUUID item
                else if ("i".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    siPosX = startLocation.x;
                    siPosY = startLocation.y;
                } 
                // Board Serial Number item
                else if ("b".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    bsniPosX = startLocation.x;
                    bsniPosY = startLocation.y;
                } 
                // Save menu
                else if ("v".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    svmPosX = startLocation.x;
                    svmPosY = startLocation.y;
                } 
                // Save item
                else if ("z".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    sviPosX = startLocation.x;
                    sviPosY = startLocation.y;
                } 
                // end
                else if ("a".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    endPosX = startLocation.x;
                    endPosY = startLocation.y;
                } 
                // ok
                else if ("k".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    okPosX = startLocation.x;
                    okPosY = startLocation.y;
                } 
                // Mount EFI menu
                else if ("1".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    emPosX = startLocation.x;
                    emPosY = startLocation.y;
                } 
                // Mount Partition
                else if ("2".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    mpiPosX = startLocation.x;
                    mpiPosY = startLocation.y;
                } 
                // Open Partition
                else if ("3".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    opiPosX = startLocation.x;
                    opiPosY = startLocation.y;
                } 
                // EFI folder
                else if ("4".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    efPosX = startLocation.x;
                    efPosY = startLocation.y;
                } 
                // Clover folder
                else if ("5".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    cfPosX = startLocation.x;
                    cfPosY = startLocation.y;
                } 
                // Config.plist file 
                else if ("6".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    cpPosX = startLocation.x;
                    cpPosY = startLocation.y;
                } 
                else {
                    System.out.println("Bad command");
                }
            }
        }
        keyboard.close();
    }
}

class AppleScript {
    public void run(String name, String code) throws Throwable{
        PrintStream ps = new PrintStream(name);
        ps.println(code);
        ps.close();
        Runtime.getRuntime().exec("osascript " + name);
    }
 }