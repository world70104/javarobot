find . -name "*.java"|while read file
do
	echo $file
	javac -source 1.8 -target 1.8 $file
done
