/////////////////////////////////////////////////////////////////////////
//
//                          Robot1 for Clover
//
//    auto input for 5 data & env save & rebooting
//
//  Date: 2018/09/20
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

// import files
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.reflect.Field;
import java.awt.event.*;
import javax.swing.*;
import java.io.*; 
import java.util.concurrent.TimeUnit;
import java.util.UUID;
import java.io.PrintStream;

public class CRobot1 {
    // File path
    ///////////////////    modify  for own computer  ///////////////////////
    public static String mainPath = "/Users/mac/Desktop";
    public static String rootPassword = "admin";
    /////////////////////////////////////////////////////////////////////////
    public static String ccFileNamed =  "/Clover/App/CloverConfigurator.app";
    public static String boardSNCmd =  "/Clover/MacGen-master/mg-mlb-serial";
    public static String dataFile =  "/Clover/Data/最新5码.txt";
    public static String posFileName = "/Clover/Position/CR1Pos.txt";

    // robot	
    Robot robot = null;

    // product name
    // 0 - MacBook Air 7,2
    // 1 - MacBookPro 11,5
    public static int productName = 0;  
    public static int[] productNameIndex = { 55, 36 };  
    public static String[] productNameStr = {"MacBookAir7,2", "MacBookPro11,5" };

    // index in data file
    // show data for dataIndex row in 最新5码.txt
    public static int dataIndex = 0;

    // delay value
	static int shiftDelay = 20;
    static int endDelay = 100;
    static int appDelay = 1000;

    // position
    // RtVariables Menu
    public static int rmPosX = 0; 
    public static int rmPosY = 0; 
    // ROM
    public static int riPosX = 0; 
    public static int riPosY = 0; 
    // MLB
    public static int miPosX = 0; 
    public static int miPosY = 0; 
    // SMBIOS Menu
    public static int smPosX = 0; 
    public static int smPosY = 0; 
    // Product name Combobox
    public static int pncPosX = 0; 
    public static int pncPosY = 0; 
    // Serial Number
    public static int sniPosX = 0; 
    public static int sniPosY = 0; 
    // SmUUID
    public static int siPosX = 0; 
    public static int siPosY = 0; 
    // Board SN
    public static int bsniPosX = 0; 
    public static int bsniPosY = 0; 
    // Save menu
    public static int svmPosX = 0; 
    public static int svmPosY = 0; 
    // Save item
    public static int sviPosX = 0; 
    public static int sviPosY = 0; 
    // end
    public static int endPosX = 0; 
    public static int endPosY = 0; 
    // ok
    public static int okPosX = 0; 
    public static int okPosY = 0; 
    // mount EFI
    public static int emPosX = 0; 
    public static int emPosY = 0; 
    // mount patition 
    public static int mpiPosX = 0; 
    public static int mpiPosY = 0;
    // open patition 
    public static int opiPosX = 0; 
    public static int opiPosY = 0; 
    // EFI folder 
    public static int efPosX = 0; 
    public static int efPosY = 0; 
    // Clover folder 
    public static int cfPosX = 0; 
    public static int cfPosY = 0; 
    // Config.plist file 
    public static int cpPosX = 0; 
    public static int cpPosY = 0; 

    // write string
    public static void parseChars(Robot robot, String letter) {
        for (int i = 0; i < letter.length(); i ++) {
            char chary = letter.charAt(i);
            typeCharacter(robot, Character.toString(chary));
        }
    }

    // write char
    public static void typeCharacter(Robot robot, String letter) {
        for ( int i = 0; i < letter.length(); i++ ) {
            char a_char = letter.charAt(0);
            if( Character.isLetterOrDigit( a_char ) )
            {
                if(a_char >= '0' && a_char <= '9') {
                    oneKeyPress(robot, a_char );
                }
                else if(a_char >= 'A' && a_char <= 'Z') {
                    twoKeyPress(robot, KeyEvent.VK_SHIFT, a_char );
                }
                else if(a_char >= 'a' && a_char <= 'z') {
                    a_char -= 0x20;
                    oneKeyPress(robot, a_char );
                }                
            }
            else if ( a_char == '!' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_1 );
            }
            else if ( a_char == '@' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_2 );
            }
            else if ( a_char == '#' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_3 );
            }
            else if ( a_char == '$' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_4 );
            }
            else if ( a_char == '%' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_5 );
            }
            else if ( a_char == '^' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_6 );
            }
            else if ( a_char == '&' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_7 );
            }
            else if ( a_char == '*' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_8 );
            }
            else if ( a_char == '(' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_9 );
            }
            else if ( a_char == ')' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_0 );
            }
            else if ( a_char == '_' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '-' );
            }
            else if ( a_char == '+' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '=' );
            }
            else if ( a_char == '{' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '[' );
            }
            else if ( a_char == '}' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, ']' );
            }
            else if ( a_char == '<' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_COMMA );
            }
            else if ( a_char == '>' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '.' );
            }
            else if ( a_char == '?' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '/' );
            }
            else if( a_char == ',' )  {
                oneKeyPress(robot, KeyEvent.VK_COMMA );
            }
            else  {
                oneKeyPress(robot, a_char );
            }
        }
    }

    //    move the ouse as person
    public static void MouseMoveThread(  Robot _robot,  int endX, int endY,
        int numberOfIterations, long timeToSleep ) {
        int startX;
        int startY;
        int currentX;
        int currentY;
        int xAmount;
        int yAmount;
        int xAmountPerIteration;
        int yAmountPerIteration;
                    
            Robot robot =  _robot;
            Point startLocation = MouseInfo.getPointerInfo().getLocation();
            startX = startLocation.x;
            startY = startLocation.y;
            if ( endX > startX )
                xAmount = endX - startX;
            else
                xAmount = startX - endX;
            
            if ( endY > startY )
                yAmount = endY - startY;
            else
                yAmount = startY - endY;

            currentX = startX;
            currentY = startY;

            xAmountPerIteration = xAmount / numberOfIterations;
            yAmountPerIteration = yAmount / numberOfIterations;

            if( endX >= startX ) {
                if ( endY >= startY ) {
                    while ( currentX < endX &&
                            currentY < endY ) {

                        currentX += xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX < endX &&
                            currentY > endY ) {

                        currentX += xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
            else {
                if ( endY >= startY ) {
                    while ( currentX > endX &&
                            currentY < endY ) {

                        currentX -= xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX > endX &&
                            currentY > endY ) {

                        currentX -= xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
    }

    // Read the position for robot 
    public static void posFileRead() {
        File f = new File(mainPath + posFileName);
        if( !(f.exists() && !f.isDirectory()) ) { 
            return;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(mainPath + posFileName));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                rmPosX = Integer.parseInt(line);
                int i = 0;
                while (line != null) {
                    line = br.readLine();
                    if ( i == 0 ) {
                        rmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 1 ) {
                        riPosX = Integer.parseInt(line);
                    }
                    else if ( i == 2 ) {
                        riPosY = Integer.parseInt(line);
                    }
                    else if ( i == 3 ) {
                        miPosX = Integer.parseInt(line);
                    }
                    else if ( i == 4 ) {
                        miPosY = Integer.parseInt(line);
                    }
                    else if ( i == 5 ) {
                        smPosX = Integer.parseInt(line);
                    }
                    else if ( i == 6 ) {
                        smPosY = Integer.parseInt(line);
                    }
                    else if ( i == 7 ) {
                        pncPosX = Integer.parseInt(line);
                    }
                    else if ( i == 8 ) {
                        pncPosY = Integer.parseInt(line);
                    }
                    else if ( i == 9 ) {
                        sniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 10 ) {
                        sniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 11 ) {
                        siPosX = Integer.parseInt(line);
                    }
                    else if ( i == 12 ) {
                        siPosY = Integer.parseInt(line);
                    }
                    else if ( i == 13 ) {
                        bsniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 14 ) {
                        bsniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 15 ) {
                        svmPosX = Integer.parseInt(line);
                    }
                    else if ( i == 16 ) {
                        svmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 17 ) {
                        sviPosX = Integer.parseInt(line);
                    }
                    else if ( i == 18 ) {
                        sviPosY = Integer.parseInt(line);
                    }
                    else if ( i == 19 ) {
                        endPosX = Integer.parseInt(line);
                    }
                    else if ( i == 20 ) {
                        endPosY = Integer.parseInt(line);
                    }
                    else if ( i == 21 ) {
                        okPosX = Integer.parseInt(line);
                    }
                    else if ( i == 22 ) {
                        okPosY = Integer.parseInt(line);
                    }
                    else if ( i == 23 ) {
                        emPosX = Integer.parseInt(line);
                    }
                    else if ( i == 24 ) {
                        emPosY = Integer.parseInt(line);
                    }
                    else if ( i == 25 ) {
                        mpiPosX = Integer.parseInt(line);
                    }
                    else if ( i == 26 ) {
                        mpiPosY = Integer.parseInt(line);
                    }
                    else if ( i == 27 ) {
                        opiPosX = Integer.parseInt(line);
                    }
                    else if ( i == 28 ) {
                        opiPosY = Integer.parseInt(line);
                    }
                    else if ( i == 29 ) {
                        efPosX = Integer.parseInt(line);
                    }
                    else if ( i == 30 ) {
                        efPosY = Integer.parseInt(line);
                    }
                    // Clover folder
                    else if ( i == 31 ) {
                        cfPosX = Integer.parseInt(line);
                    }
                    else if ( i == 32 ) {
                        cfPosY = Integer.parseInt(line);
                    }
                    // Config.plist file
                    else if ( i == 33 ) {
                        cpPosX = Integer.parseInt(line);
                    }
                    else if ( i == 34 ) {
                        cpPosY = Integer.parseInt(line);
                    }
                    i++;
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }

    }
    
    // move message window (  0, 0 )
    public static void moveMessageWindow() throws Throwable {

        // Set the Clover Configurator window position (0,0)
        String code = "";
        code += "tell application \"System Events\" to tell process \"Clover Configurator\"\n";
        code += "    tell application \"Clover Configurator\" to activate\n";
        code += "    tell front window to set position to {0, 0}\n";
        code += "end tell\n";
        new AppleScript().run("move_win.as", code);
        Thread.sleep(appDelay);
    }
    // move Finder window (  0, 0 )
    public static void moveFindWindow() throws Throwable {

        // Set the Clover Configurator window position (0,0)
        String code = "";
        code += "tell application \"System Events\" to tell process \"Finder\"\n";
        code += "    tell application \"Finder\" to activate\n";
        code += "    tell front window to set position to {0, 0}\n";
        code += "end tell\n";
        new AppleScript().run("move_win.as", code);
        Thread.sleep(appDelay);
    }
    
    // mouse one click
    public static void mouseOneClick(Robot robot) {
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(endDelay);
    }

    // mouse two click
    public static void mouseTwoClick(Robot robot) {
        mouseOneClick(robot);
        mouseOneClick(robot);
    }

    // mouse direct move
    public static void mouseDirectMove(Robot robot, int x, int y ) {
        robot.mouseMove( x, y );
        robot.delay(2);
    }

    // mouse delay move
    public static void mouseDelayMove(Robot robot, int x, int y ) {
        MouseMoveThread( robot, x, y, 100, 5 );
        robot.mouseMove( x, y );
        robot.delay(2);
    }

     // one key press
    public static void oneKeyPress(Robot robot, int keyCode ) {
        robot.keyPress( keyCode );
        robot.keyRelease( keyCode );
        robot.delay(endDelay);
    }

     // two key press
     public static void twoKeyPress(Robot robot, int keyCode1, int keyCode2 ) {
        robot.keyPress( keyCode1 );
        robot.delay( shiftDelay );
        robot.keyPress( keyCode2 );
        robot.keyRelease( keyCode2 );
        robot.delay( shiftDelay );
        robot.keyRelease( keyCode1 );
        robot.delay( endDelay );
    }

    // main 
	public static void main(String[] args) throws Throwable {

        // execute Clover Configurator 
        try {
            Runtime runtime = Runtime.getRuntime();
            String s= "open " + mainPath + ccFileNamed;
            Process proc = runtime.exec(s);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the Clover Configurator window position (0,0)
        moveMessageWindow();

        // modify the 5 data
        CRobot1 mainObj = new CRobot1();
        // make robot
        try { 
            mainObj.robot = new Robot(); 
        }
        catch (Exception ex) { 
            ex.printStackTrace(); 
        }

        // If pos file, read
        posFileRead();

        // action start
        mainObj.robot.delay(endDelay);
        // Go to Mount EFI Menu
        mouseDelayMove(mainObj.robot, emPosX,  emPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Go to Mount Partition
        mouseDelayMove(mainObj.robot, mpiPosX,  mpiPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Go to Open Partition
        mouseDelayMove(mainObj.robot, opiPosX,  opiPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Set the Finder window position (0,0)
        moveFindWindow();
        mainObj.robot.delay(endDelay);
        Thread.sleep(appDelay);

        // Go to EFI folder
        mouseDelayMove(mainObj.robot, efPosX,  efPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Go to Clover folder
        mouseDirectMove(mainObj.robot, cfPosX,  cfPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Go to Config.plist file 
        mouseDirectMove(mainObj.robot, cpPosX,  cpPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // Set the Clover Configurator window position (0,0)
        moveMessageWindow();

        // Go to RtVariables Menu
        Thread.sleep(appDelay);
        mouseDelayMove(mainObj.robot, rmPosX,  rmPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // read 5 data
        String lineROM = "";
        String lineMLB = "";
        String lineSN = "";
        int lineIdx = 0;
        try {
            BufferedReader br = new BufferedReader(new FileReader( mainPath + dataFile ));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                while (line != null) {
                    int leng = line.length();
                    if ( leng != 0 ) {
                        if ( lineIdx == dataIndex ) {
                            int i;
                            // ROM seperate
                            boolean start = false;
                            for ( i = 0; i < leng ; i++ ) {
                                if ( line.charAt(i) == ':'  ) {
                                    if ( !start ) 
                                        start = true;
                                    else {
                                        break;
                                    }    
                                }     
                                else {
                                    if ( start ) {
                                        lineROM += Character.toString(line.charAt(i));    
                                    }
                                }                      
                            }
                            // MLB seperate
                            for ( i++; i < leng ; i++ ) {
                                if ( line.charAt(i) == ':'  ) {
                                        break;
                                }     
                                else {
                                    if ( start ) {
                                        lineMLB += Character.toString(line.charAt(i));    
                                    }
                                }                      
                            }
                            // Serial number seperate
                            for ( i++; i < leng ; i++ ) {
                                if ( line.charAt(i) == ':'  ) {
                                        break;
                                }     
                                else {
                                    if ( start ) {
                                        lineSN += Character.toString(line.charAt(i));    
                                    }
                                }                      
                            }
                            break;
                        }
                        else {
                            lineIdx += 1;
                        }
                    }
                    line = br.readLine();
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }	
        // Go to ROM
        mouseDelayMove(mainObj.robot, riPosX,  riPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);

        // delete key
        oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );
        System.out.println( "ROM : " + lineROM); 
        parseChars(mainObj.robot, lineROM);

        // Go to MLB
        mouseDelayMove(mainObj.robot, miPosX,  miPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);
        // delete key
        oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );
        System.out.println( "MLB : " + lineMLB); 
        parseChars(mainObj.robot, lineMLB);

        // Go to SMBIOS Menu
        mouseDelayMove(mainObj.robot, smPosX,  smPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);
        // delete key
        oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );

        // Go to Product name Combobox
        mouseDelayMove(mainObj.robot, pncPosX,  pncPosY );
        // mouse click
        mouseOneClick(mainObj.robot);
        // go to first position
        for ( int j = 0; j < 105; j++ ) {
            // key up                         
            oneKeyPress(mainObj.robot, KeyEvent.VK_UP );
        }
        // go to right position
        for ( int j = 0; j < productNameIndex[ productName ]; j++ ) {
            // key down                         
            oneKeyPress(mainObj.robot, KeyEvent.VK_DOWN );
        }
        // key Enter                         
        oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );

        // Go to Serial Number
        mouseDelayMove(mainObj.robot, sniPosX,  sniPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);
        // delete key
        oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );

        System.out.println( "Serial Number : " + lineSN); 
        parseChars(mainObj.robot, lineSN);
   
        // Go to SmUUID
        mouseDelayMove(mainObj.robot, siPosX,  siPosY );
        for ( int cnt = 0; cnt < 9; cnt ++ ) {
            // mouse click
            mouseTwoClick(mainObj.robot);
            // delete key
            oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );
        }

        UUID uuid = UUID.randomUUID();
        String lineUUID = uuid.toString().toUpperCase();
        System.out.println( "SmUUID : " + lineUUID); 
        parseChars(mainObj.robot, lineUUID);

        // Go to Board SN
        mouseDelayMove(mainObj.robot, bsniPosX,  bsniPosY );
        // mouse click
        mouseTwoClick(mainObj.robot);
        // delete key
        oneKeyPress(mainObj.robot, KeyEvent.VK_DELETE );
        mainObj.robot.delay(endDelay);
        mainObj.robot.delay(endDelay);

        // Board SN
        String lineBroadSN = null;
        Runtime rt = Runtime.getRuntime();
        String argStr = productNameStr[productName];
        String[] commands = { mainPath + boardSNCmd, argStr, lineSN };
        Process proc = rt.exec(commands);

        BufferedReader stdInput = new BufferedReader(new 
            InputStreamReader(proc.getInputStream()));

        BufferedReader stdError = new BufferedReader(new 
            InputStreamReader(proc.getErrorStream()));

            // read the output from the command
            while ((lineBroadSN = stdInput.readLine()) != null) {
                // parse serial number
                String tmpStr = "MLB serial number:";     
                if ( lineBroadSN.toLowerCase().contains(tmpStr.toLowerCase()) ) {
                    tmpStr = lineBroadSN;
                    String newlineBroadSN = "";
                    for( int j = tmpStr.length() - 17; j < tmpStr.length(); j++ ) {
                        newlineBroadSN += Character.toString(tmpStr.charAt(j));
                    }
                    System.out.println( "Board Serial Number : " + newlineBroadSN); 
                    parseChars(mainObj.robot, newlineBroadSN);
                    break;
                }
            }
            // read any errors from the attempted command
            String s = null;
            while ((s = stdError.readLine()) != null) {
                System.out.println("Board SN get error");
            }

        // Go to Save menu
        mouseDelayMove(mainObj.robot, svmPosX,  svmPosY );
        // mouse click
        mouseOneClick(mainObj.robot);

        // Go to Save item
        mouseDirectMove(mainObj.robot, sviPosX,  sviPosY );
        // mouse click
        mouseOneClick(mainObj.robot);

        // Go to end
        mouseDelayMove(mainObj.robot, endPosX,  endPosY );
        // mouse click
        mouseOneClick(mainObj.robot);

        // Go to ok
        mouseDelayMove(mainObj.robot, okPosX,  okPosY );
        // mouse click
        mouseOneClick(mainObj.robot);

        // Rebooting
        try {
            Runtime runtime = Runtime.getRuntime();
            String array[]={
                "/bin/sh", 
                "-c",
//                "echo " + rootPassword + " | sudo -S reboot"
                "echo " + rootPassword + " | sudo -S shutdown -r now"
            };
            Process proc1 = runtime.exec(array);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

class AppleScript {
    public void run(String name, String code) throws Throwable{
        PrintStream ps = new PrintStream(name);
        ps.println(code);
        ps.close();
        Runtime.getRuntime().exec("osascript " + name);
    }
 }
