/////////////////////////////////////////////////////////////////////////
//
//                          CR2GetPos 
//
//    get the position for CRobot2
//
//  Date: 2018/09/20
//  Version: 1.0
//
//  Make by M.H team
//
//////////////////////////////////////////////////////////////////////////

// import files
import java.util.Scanner;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.reflect.Field;
import java.awt.event.*;
import javax.swing.*;
import java.io.*; 
import java.util.concurrent.TimeUnit;
import java.util.UUID;
import java.io.File;
import java.io.PrintStream;

public class CR2GetPos {
    // File path
    public static String mainPath = "/Volumes/Data/iSCAN";
    public static String posFileName = "/Clover/Position/CR2Pos.txt";
    public static String password = "123";
    // robot	
    Robot robot = null;
    // delay value
	static int shiftDelay = 50;
    static int endDelay = 200;
    static int appDelay = 1000;

    // first screen
    public static int fsPosX = 0; 
    public static int fsPosY = 0; 
    public static int fsRed = 0; 
    public static int fsGreen = 0; 
    public static int fsBlue = 0; 
    // boot screen
    public static int bsPosX = 0; 
    public static int bsPosY = 0; 
    public static int bsRed = 0; 
    public static int bsGreen = 0; 
    public static int bsBlue = 0; 
    // password screen
    public static int psPosX = 0; 
    public static int psPosY = 0; 
    public static int psRed = 0; 
    public static int psGreen = 0; 
    public static int psBlue = 0; 

    public static void parseChars(Robot robot, String letter) {
        for (int i = 0; i < letter.length(); i ++) {
            char chary = letter.charAt(i);
            typeCharacter(robot, Character.toString(chary));
        }
    }

    public static void typeCharacter(Robot robot, String letter) {
        for ( int i = 0; i < letter.length(); i++ ) {
            char a_char = letter.charAt(0);
            if( Character.isLetterOrDigit( a_char ) )
            {
                if(a_char >= '0' && a_char <= '9') {
                    oneKeyPress(robot, a_char );
                }
                else if(a_char >= 'A' && a_char <= 'Z') {
                    twoKeyPress(robot, KeyEvent.VK_SHIFT, a_char );
                }
                else if(a_char >= 'a' && a_char <= 'z') {
                    a_char -= 0x20;
                    oneKeyPress(robot, a_char );
                }                
            }
            else if ( a_char == '!' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_1 );
            }
            else if ( a_char == '@' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_2 );
            }
            else if ( a_char == '#' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_3 );
            }
            else if ( a_char == '$' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_4 );
            }
            else if ( a_char == '%' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_5 );
            }
            else if ( a_char == '^' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_6 );
            }
            else if ( a_char == '&' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_7 );
            }
            else if ( a_char == '*' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_8 );
            }
            else if ( a_char == '(' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_9 );
            }
            else if ( a_char == ')' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_0 );
            }
            else if ( a_char == '_' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '-' );
            }
            else if ( a_char == '+' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '=' );
            }
            else if ( a_char == '{' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '[' );
            }
            else if ( a_char == '}' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, ']' );
            }
            else if ( a_char == '<' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_COMMA );
            }
            else if ( a_char == '>' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '.' );
            }
            else if ( a_char == '?' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '/' );
            }
            else if( a_char == ',' )  {
                oneKeyPress(robot, KeyEvent.VK_COMMA );
            }
            else  {
                oneKeyPress(robot, a_char );
            }
        }
    }

    ////////////////////////////   Mouse move    ////////////////////////
    public static void MouseMoveThread(  Robot _robot,  int endX, int endY,
        int numberOfIterations, long timeToSleep ) {
        int startX;
        int startY;
        int currentX;
        int currentY;
        int xAmount;
        int yAmount;
        int xAmountPerIteration;
        int yAmountPerIteration;
                    
            Robot robot =  _robot;
            Point startLocation = MouseInfo.getPointerInfo().getLocation();
            startX = startLocation.x;
            startY = startLocation.y;
            if ( endX > startX )
                xAmount = endX - startX;
            else
                xAmount = startX - endX;
            
            if ( endY > startY )
                yAmount = endY - startY;
            else
                yAmount = startY - endY;

            currentX = startX;
            currentY = startY;

            xAmountPerIteration = xAmount / numberOfIterations;
            yAmountPerIteration = yAmount / numberOfIterations;

            if( endX >= startX ) {
                if ( endY >= startY ) {
                    while ( currentX < endX &&
                            currentY < endY ) {

                        currentX += xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX < endX &&
                            currentY > endY ) {

                        currentX += xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
            else {
                if ( endY >= startY ) {
                    while ( currentX > endX &&
                            currentY < endY ) {

                        currentX -= xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX > endX &&
                            currentY > endY ) {

                        currentX -= xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
    }
    /////////////////////////////////////////////////////////////////////

    // Write the position for robot
    public static void posFileSave() {
        try (PrintWriter out = new PrintWriter( mainPath + posFileName )) {
            String textStr = Integer.toString(fsPosX);
            out.println(textStr);
            textStr = Integer.toString(fsPosY);
            out.println(textStr);
            textStr = Integer.toString(fsRed);
            out.println(textStr);
            textStr = Integer.toString(fsGreen);
            out.println(textStr);
            textStr = Integer.toString(fsBlue);
            out.println(textStr);
            textStr = Integer.toString(bsPosX);
            out.println(textStr);
            textStr = Integer.toString(bsPosY);
            out.println(textStr);
            textStr = Integer.toString(bsRed);
            out.println(textStr);
            textStr = Integer.toString(bsGreen);
            out.println(textStr);
            textStr = Integer.toString(bsBlue);
            out.println(textStr);
            textStr = Integer.toString(psPosX);
            out.println(textStr);
            textStr = Integer.toString(psPosY);
            out.println(textStr);
            textStr = Integer.toString(psRed);
            out.println(textStr);
            textStr = Integer.toString(psGreen);
            out.println(textStr);
            textStr = Integer.toString(psBlue);
            out.println(textStr);
        }
        catch (IOException e) {
//            e.printStackTrace();
        }
    }

    // Read the position for robot
    public static void posFileRead() {
        File f = new File( mainPath + posFileName );
        if( !(f.exists() && !f.isDirectory()) ) { 
            return;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader( mainPath + posFileName ));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                fsPosX = Integer.parseInt(line);
                int i = 0;
                while (line != null) {
                    line = br.readLine();
                    if ( i == 0 ) {
                        fsPosY = Integer.parseInt(line);
                    }
                    else if ( i == 1 ) {
                        fsRed = Integer.parseInt(line);
                    }
                    else if ( i == 2 ) {
                        fsGreen = Integer.parseInt(line);
                    }
                    else if ( i == 3 ) {
                        fsBlue = Integer.parseInt(line);
                    }
                    else if ( i == 4 ) {
                        bsPosX = Integer.parseInt(line);
                    }
                    else if ( i == 5 ) {
                        bsPosY = Integer.parseInt(line);
                    }
                    else if ( i == 6 ) {
                        bsRed = Integer.parseInt(line);
                    }
                    else if ( i == 7 ) {
                        bsGreen = Integer.parseInt(line);
                    }
                    else if ( i == 8 ) {
                        bsBlue = Integer.parseInt(line);
                    }
                    else if ( i == 9 ) {
                        psPosX = Integer.parseInt(line);
                    }
                    else if ( i == 10 ) {
                        psPosY = Integer.parseInt(line);
                    }
                    else if ( i == 11 ) {
                        psRed = Integer.parseInt(line);
                    }
                    else if ( i == 12 ) {
                        psGreen = Integer.parseInt(line);
                    }
                    else if ( i == 13 ) {
                        psBlue = Integer.parseInt(line);
                    }
                    i++;
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }

    }
    // move message window (  0, 0 )
    public static void moveMessageWindow() throws Throwable {

            // Set the Clover Configurator window position (0,0)
            String code = "";
            code += "tell application \"System Events\" to tell process \"Messages\"\n";
            code += "    tell application \"Messages\" to activate\n";
            code += "    tell front window to set position to {0, 0}\n";
            code += "end tell\n";
            new AppleScript().run("move_win.as", code);
            Thread.sleep(appDelay);
    }
    
    // mouse one click
    public static void mouseOneClick(Robot robot) {
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(endDelay);
    }

    // mouse two click
    public static void mouseTwoClick(Robot robot) {
        mouseOneClick(robot);
        mouseOneClick(robot);
    }

    // mouse direct move
    public static void mouseDirectMove(Robot robot, int x, int y ) {
        robot.mouseMove( x, y );
        robot.delay(2);
    }

    // mouse delay move
    public static void mouseDelayMove(Robot robot, int x, int y ) {
        MouseMoveThread( robot, x, y, 100, 5 );
        robot.mouseMove( x, y );
        robot.delay(2);
    }

     // one key press
    public static void oneKeyPress(Robot robot, int keyCode ) {
        robot.keyPress( keyCode );
        robot.keyRelease( keyCode );
        robot.delay(endDelay);
    }

     // two key press
     public static void twoKeyPress(Robot robot, int keyCode1, int keyCode2 ) {
        robot.keyPress( keyCode1 );
        robot.delay( shiftDelay );
        robot.keyPress( keyCode2 );
        robot.keyRelease( keyCode2 );
        robot.delay( shiftDelay );
        robot.keyRelease( keyCode1 );
        robot.delay( endDelay );
    }

	public static void main(String[] args) throws Throwable {

        CR2GetPos mainObj = new CR2GetPos();
        // make robot
        try { 
            mainObj.robot = new Robot(); 
        }
        catch (Exception ex) { 
            ex.printStackTrace(); 
        }        

        Scanner keyboard = new Scanner(System.in);
        boolean exit = false;
        
        // If pos file, read
        posFileRead();

        while (!exit) {
            System.out.println("-------------------------");
            System.out.println("Enter command");

            // first screen
            if ( fsPosX == 0 )
                System.out.println("u to first screen"); 
            else {
                String str = "u to first screen - x:";
                String add = Integer.toString(fsPosX);
                str += add;
                str += " y:";
                add = Integer.toString(fsPosY);
                str += add;
                str += " R:";
                add = Integer.toString(fsRed);
                str += add;
                str += " G:";
                add = Integer.toString(fsGreen);
                str += add;
                str += " B:";
                add = Integer.toString(fsBlue);
                str += add;
                System.out.println(str);
            }
            
            // boot screen
            if ( bsPosX == 0 )
                System.out.println("r to boot screen"); 
            else {
                String str = "r to boot screen - x:";
                String add = Integer.toString(bsPosX);
                str += add;
                str += " y:";
                add = Integer.toString(bsPosY);
                str += add;
                str += " R:";
                add = Integer.toString(bsRed);
                str += add;
                str += " G:";
                add = Integer.toString(bsGreen);
                str += add;
                str += " B:";
                add = Integer.toString(bsBlue);
                str += add;
                System.out.println(str);
            }
            
            // password screen
            if ( psPosX == 0 )
                System.out.println("m to password screen"); 
            else {
                String str = "m to password screen - x:";
                String add = Integer.toString(psPosX);
                str += add;
                str += " y:";
                add = Integer.toString(psPosY);
                str += add;
                str += " R:";
                add = Integer.toString(psRed);
                str += add;
                str += " G:";
                add = Integer.toString(psGreen);
                str += add;
                str += " B:";
                add = Integer.toString(psBlue);
                str += add;
                System.out.println(str);
            }
            System.out.println("e to save"); 
            System.out.println("q to exit"); 
            System.out.println("-------------------------");

            String input = keyboard.nextLine();
            if(input != null) {
                // Quit
                if ("q".equals(input)) {
                    exit = true;
                } 
                // Save
                else if ("e".equals(input)) {
                    posFileSave();
                } 
                    // first screen
                else if ("u".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    fsPosX = startLocation.x;
                    fsPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(fsPosX, fsPosY);
                    fsRed = color.getRed();
                    fsGreen = color.getGreen();
                    fsBlue = color.getBlue();
                } 
                // boot screen
                else if ("r".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    bsPosX = startLocation.x;
                    bsPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(bsPosX, bsPosY);
                    bsRed = color.getRed();
                    bsGreen = color.getGreen();
                    bsBlue = color.getBlue();
                } 
                // password menu
                else if ("m".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    psPosX = startLocation.x;
                    psPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(bsPosX, bsPosY);
                    psRed = color.getRed();
                    psGreen = color.getGreen();
                    psBlue = color.getBlue();
                } 
                else {
                    System.out.println("Bad command");
                }
            }
        }
        keyboard.close();
    }
}

class AppleScript {
    public void run(String name, String code) throws Throwable{
        PrintStream ps = new PrintStream(name);
        ps.println(code);
        ps.close();
        Runtime.getRuntime().exec("osascript " + name);
    }
 }