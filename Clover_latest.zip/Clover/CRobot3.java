/////////////////////////////////////////////////////////////////////////
//
//      Robot3 for Clover
//
//  Date: 2018/09/18
//  Make: M.H team
//
//////////////////////////////////////////////////////////////////////////


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.reflect.Field;
import java.awt.event.*;
import javax.swing.*;
import java.io.*; 
import java.util.concurrent.TimeUnit;
import java.util.UUID;
import java.io.PrintStream;

public class CRobot3 {
    // File path
    ///////////////////    modify  for own computer  ///////////////////////
    public static String mainPath = "/Users/mac/Desktop";
    /////////////////////////////////////////////////////////////////////////
    public static String ccFileNamed =  "/Clover/App/CloverConfigurator.app";
    public static String messgesApp = "/Applications/Messages.app";
    public static String appleIdFile =  "/Clover/Data/appleID.txt";
    public static String posFileName = "/Clover/Position/CR3Pos.txt";
        // OS
    // 0 - Mac, 1 - Windows
    public static int os = 0;
    // robot	
    Robot robot = null;
    // apple ID index
    public static int appIDindex = 0;  
   
    // delay value
	static int shiftDelay = 50;
    static int endDelay = 200;
    static int appDelay = 1000;
    // persion item
    public static int rmPosX = 0; 
    public static int rmPosY = 0; 
    // delete
    public static int riPosX = 0; 
    public static int riPosY = 0; 
    // Accounts menu
    public static int miPosX = 0; 
    public static int miPosY = 0; 
    // Sign out
    public static int smPosX = 0; 
    public static int smPosY = 0; 
    // Sign out OK
    public static int pncPosX = 0; 
    public static int pncPosY = 0; 
    // Accounts close
    public static int sniPosX = 0; 
    public static int sniPosY = 0; 
    // password
    public static int psPosX = 0; 
    public static int psPosY = 0; 
    public static int psRed = 0; 
    public static int psGreen = 0; 
    public static int psBlue = 0; 
    // pos & color for execute conform
    public static int fsPosX = 0; 
    public static int fsPosY = 0; 
    public static int fsRed = 0; 
    public static int fsGreen = 0; 
    public static int fsBlue = 0; 
    // pos for first  signin password
    public static int fspPosX = 0; 
    public static int fspPosY = 0; 
    // first  signin successful confirm
    public static int fscPosX = 0; 
    public static int fscPosY = 0; 
    // first  signin error
    public static int fsePosX = 0; 
    public static int fsePosY = 0; 
    // enter apple id
    public static int eaPosX = 0; 
    public static int eaPosY = 0; 
    // enter red id pass incorrect  message  in first signin
    public static int red1PosX = 0; 
    public static int red1PosY = 0; 
        // enter auth error  message  in second signin
    // Could not sign in to iMessage
    public static int yelPosX = 0; 
    public static int yelPosY = 0; 
    public static int yelRed = 0; 
    public static int yelGreen = 0; 
    public static int yelBlue = 0; 
    // end signin ok
    public static int sokPosX = 0; 
    public static int sokPosY = 0; 


    // out the string
    public static void parseChars(Robot robot, String letter) {
        for (int i = 0; i < letter.length(); i ++) {
            char chary = letter.charAt(i);
            typeCharacter(robot, Character.toString(chary));
        }
    }

    // out the chracter
    public static void typeCharacter(Robot robot, String letter) {
        for ( int i = 0; i < letter.length(); i++ ) {
            char a_char = letter.charAt(0);
            if( Character.isLetterOrDigit( a_char ) )
            {
                if(a_char >= '0' && a_char <= '9') {
                    oneKeyPress(robot, a_char );
                }
                else if(a_char >= 'A' && a_char <= 'Z') {
                    twoKeyPress(robot, KeyEvent.VK_SHIFT, a_char );
                }
                else if(a_char >= 'a' && a_char <= 'z') {
                    a_char -= 0x20;
                    oneKeyPress(robot, a_char );
                }                
            }
            else if ( a_char == '!' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_1 );
            }
            else if ( a_char == '@' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_2 );
            }
            else if ( a_char == '#' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_3 );
            }
            else if ( a_char == '$' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_4 );
            }
            else if ( a_char == '%' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_5 );
            }
            else if ( a_char == '^' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_6 );
            }
            else if ( a_char == '&' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_7 );
            }
            else if ( a_char == '*' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_8 );
            }
            else if ( a_char == '(' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_9 );
            }
            else if ( a_char == ')' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_0 );
            }
            else if ( a_char == '_' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '-' );
            }
            else if ( a_char == '+' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '=' );
            }
            else if ( a_char == '{' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '[' );
            }
            else if ( a_char == '}' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, ']' );
            }
            else if ( a_char == '<' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_COMMA );
            }
            else if ( a_char == '>' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '.' );
            }
            else if ( a_char == '?' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '/' );
            }
            else if( a_char == ',' )  {
                oneKeyPress(robot, KeyEvent.VK_COMMA );
            }
            else  {
                oneKeyPress(robot, a_char );
            }
        }
    }

    ////////////////////////////   Mouse move    ////////////////////////
    public static void MouseMoveThread(  Robot _robot,  int endX, int endY,
        int numberOfIterations, long timeToSleep ) {
        int startX;
        int startY;
        int currentX;
        int currentY;
        int xAmount;
        int yAmount;
        int xAmountPerIteration;
        int yAmountPerIteration;
                    
            Robot robot =  _robot;
            Point startLocation = MouseInfo.getPointerInfo().getLocation();
            startX = startLocation.x;
            startY = startLocation.y;
            if ( endX > startX )
                xAmount = endX - startX;
            else
                xAmount = startX - endX;
            
            if ( endY > startY )
                yAmount = endY - startY;
            else
                yAmount = startY - endY;

            currentX = startX;
            currentY = startY;

            xAmountPerIteration = xAmount / numberOfIterations;
            yAmountPerIteration = yAmount / numberOfIterations;

            if( endX >= startX ) {
                if ( endY >= startY ) {
                    while ( currentX < endX &&
                            currentY < endY ) {

                        currentX += xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX < endX &&
                            currentY > endY ) {

                        currentX += xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
            else {
                if ( endY >= startY ) {
                    while ( currentX > endX &&
                            currentY < endY ) {

                        currentX -= xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX > endX &&
                            currentY > endY ) {

                        currentX -= xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
    }
    /////////////////////////////////////////////////////////////////////

    // Read the position for robot
    public static void posFileRead() {
        File f = new File(mainPath + posFileName);
        if( !(f.exists() && !f.isDirectory()) ) { 
            return;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader(mainPath + posFileName));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                rmPosX = Integer.parseInt(line);
                int i = 0;
                while (line != null) {
                    line = br.readLine();
                    if ( i == 0 ) {
                        rmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 1 ) {
                        riPosX = Integer.parseInt(line);
                    }
                    else if ( i == 2 ) {
                        riPosY = Integer.parseInt(line);
                    }
                    else if ( i == 3 ) {
                        miPosX = Integer.parseInt(line);
                    }
                    else if ( i == 4 ) {
                        miPosY = Integer.parseInt(line);
                    }
                    else if ( i == 5 ) {
                        smPosX = Integer.parseInt(line);
                    }
                    else if ( i == 6 ) {
                        smPosY = Integer.parseInt(line);
                    }
                    else if ( i == 7 ) {
                        pncPosX = Integer.parseInt(line);
                    }
                    else if ( i == 8 ) {
                        pncPosY = Integer.parseInt(line);
                    }
                    else if ( i == 9 ) {
                        sniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 10 ) {
                        sniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 11 ) {
                        psPosX = Integer.parseInt(line);
                    }
                    else if ( i == 12 ) {
                        psPosY = Integer.parseInt(line);
                    }
                    else if ( i == 13 ) {
                        psRed = Integer.parseInt(line);
                    }
                    else if ( i == 14 ) {
                        psGreen = Integer.parseInt(line);
                    }
                    else if ( i == 15 ) {
                        psBlue = Integer.parseInt(line);
                    }
                    else if ( i == 16 ) {
                        fsPosX = Integer.parseInt(line);
                    }
                    else if ( i == 17 ) {
                        fsPosY = Integer.parseInt(line);
                    }
                    else if ( i == 18 ) {
                        fsRed = Integer.parseInt(line);
                    }
                    else if ( i == 19 ) {
                        fsGreen = Integer.parseInt(line);
                    }
                    else if ( i == 20 ) {
                        fsBlue = Integer.parseInt(line);
                    }
                    else if ( i == 21 ) {
                        fspPosX = Integer.parseInt(line);
                    }
                    else if ( i == 22 ) {
                        fspPosY = Integer.parseInt(line);
                    }
                    else if ( i == 23 ) {
                        fscPosX = Integer.parseInt(line);
                    }
                    else if ( i == 24 ) {
                        fscPosY = Integer.parseInt(line);
                    }
                    else if ( i == 25 ) {
                        fsePosX = Integer.parseInt(line);
                    }
                    else if ( i == 26 ) {
                        fsePosY = Integer.parseInt(line);
                    }
                    else if ( i == 27 ) {
                        eaPosX = Integer.parseInt(line);
                    }
                    else if ( i == 28 ) {
                        eaPosY = Integer.parseInt(line);
                    }
                    else if ( i == 29 ) {
                        red1PosX = Integer.parseInt(line);
                    }
                    else if ( i == 30 ) {
                        red1PosY = Integer.parseInt(line);
                    }
                    else if ( i == 31 ) {
                        yelPosX = Integer.parseInt(line);
                    }
                    else if ( i == 32 ) {
                        yelPosY = Integer.parseInt(line);
                    }
                    else if ( i == 33 ) {
                        yelRed = Integer.parseInt(line);
                    }
                    else if ( i == 34 ) {
                        yelGreen = Integer.parseInt(line);
                    }
                    else if ( i == 35 ) {
                        yelBlue = Integer.parseInt(line);
                    }
                    else if ( i == 36 ) {
                        sokPosX = Integer.parseInt(line);
                    }
                    else if ( i == 37 ) {
                        sokPosY = Integer.parseInt(line);
                    }

                    i++;
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }
    }
    
    // move message window (  0, 0 )
    public static void moveMessageWindow() throws Throwable {

        // Set the Clover Configurator window position (0,0)
        String code = "";
        code += "tell application \"System Events\" to tell process \"Messages\"\n";
        code += "    tell application \"Messages\" to activate\n";
        code += "    tell front window to set position to {0, 0}\n";
        code += "end tell\n";
        new AppleScript().run("move_win.as", code);
        Thread.sleep(appDelay);
    }
    
    // mouse one click
    public static void mouseOneClick(Robot robot) {
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(endDelay);
    }

    // mouse two click
    public static void mouseTwoClick(Robot robot) {
        mouseOneClick(robot);
        mouseOneClick(robot);
    }

    // mouse direct move
    public static void mouseDirectMove(Robot robot, int x, int y ) {
        robot.mouseMove( x, y );
        robot.delay(2);
    }

    // mouse delay move
    public static void mouseDelayMove(Robot robot, int x, int y ) {
        MouseMoveThread( robot, x, y, 100, 5 );
        robot.mouseMove( x, y );
        robot.delay(2);
    }

     // one key press
    public static void oneKeyPress(Robot robot, int keyCode ) {
        robot.keyPress( keyCode );
        robot.keyRelease( keyCode );
        robot.delay(endDelay);
    }

     // two key press
     public static void twoKeyPress(Robot robot, int keyCode1, int keyCode2 ) {
        robot.keyPress( keyCode1 );
        robot.delay( shiftDelay );
        robot.keyPress( keyCode2 );
        robot.keyRelease( keyCode2 );
        robot.delay( shiftDelay );
        robot.keyRelease( keyCode1 );
        robot.delay( endDelay );
    }

	public static void main(String[] args) throws Throwable {

        // execute Message app 
        try {
            Runtime runtime = Runtime.getRuntime();
            String s= "open " + messgesApp;
            Process proc = runtime.exec(s);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the Clover Configurator window position (0,0)
        moveMessageWindow();

        // read apple ID file
        int appidFileIdx = 0;
        String appidFileLine = "";
        String lineAppleID = "";
        String linePassword = "";
        // get appid & password
        try {
            BufferedReader br = new BufferedReader(new FileReader( mainPath + appleIdFile ));
            try {
                StringBuilder sb = new StringBuilder();
                appidFileLine = br.readLine();
                while (appidFileLine != null) {
                    int leng = appidFileLine.length();
                    if ( leng != 0 ) {
                        if ( appidFileIdx == appIDindex ) {    
                            // apple id seperate
                            boolean start = false;
                            int i;
                            for ( i = 0; i < leng ; i++ ) {
                                if ( appidFileLine.charAt(i) == '：'  ) {
                                    if ( !start ) 
                                        start = true;
                                    }     
                                else {
                                    if ( start ) {
                                        if ( appidFileLine.charAt(i) != '	'  )
                                            lineAppleID += Character.toString(appidFileLine.charAt(i));  
                                            else
                                        break;  
                                    }
                                }
                            }     
                            // Password seperate
                            start = false;
                            for ( i++; i < leng ; i++ ) {
                                if ( appidFileLine.charAt(i) == '：'  ) {
                                    if ( !start ) 
                                        start = true;
                                }     
                                else {
                                    if ( start ) {
                                        linePassword += Character.toString(appidFileLine.charAt(i));  
                                    }
                                }                      
                            }                   
                            break;
                        }
                        else
                            appidFileIdx += 1;
                    }
                    appidFileLine = br.readLine();
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }	

        CRobot3 mainObj = new CRobot3();
        // make robot
        try { 
            mainObj.robot = new Robot(); 
        }
        catch (Exception ex) { 
            ex.printStackTrace(); 
        }

        // If pos file, read
        posFileRead();

         mainObj.robot.delay(appDelay);
         mainObj.robot.delay(appDelay);
         mainObj.robot.delay(appDelay);

        // execute check
        int normalCheck = 0;
        mouseDelayMove( mainObj.robot, fscPosX, fscPosY );

        while(true) {
            Color color = mainObj.robot.getPixelColor(fscPosX, fscPosY);
            mainObj.robot.delay(100);
            int red = color.getRed();
            int green = color.getGreen();
            int blue = color.getBlue();
            if( 
                ( red > 240  ) &&
                ( green > 240  ) &&
                ( blue > 240  ) 
                ) {
                    normalCheck = 1;
                     System.out.println( "Message input" );
                    break; 
            }
            else {
                color = mainObj.robot.getPixelColor(fsPosX, fsPosY);
                red = color.getRed();
                green = color.getGreen();
                blue = color.getBlue();
                if(!( 
                    ( red == fsRed  ) &&
                    ( green == fsGreen  ) &&
                    ( blue == fsBlue  ) 
                    )) {
                        System.out.println( "Sign in" );
                        break; 
                }
            }
        }

        // First Sign in ?
        int status = 0;
        if ( normalCheck == 0 ) {

            // Input Apple ID for Siginin
            // Action start
            mouseDelayMove( mainObj.robot, fsPosX, fsPosY );
            // mouse click
            mouseOneClick( mainObj.robot );
            mainObj.robot.delay(appDelay);
            parseChars(mainObj.robot, lineAppleID);
            oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );
            mainObj.robot.delay(appDelay);
            System.out.println( "signin Apple ID : " + lineAppleID); 
            // show password ? 
            while(true) {
                Color color = mainObj.robot.getPixelColor(fspPosX, fspPosY);
                int red = color.getRed();
                int green = color.getGreen();
                int blue = color.getBlue();
                if(!( 
                    ( red == fsRed  ) &&
                    ( green == fsGreen  ) &&
                    ( blue == fsBlue  ) 
                    )) {
                        break; 
                }
            }
            // mouse click
            mouseDelayMove( mainObj.robot, fspPosX, fspPosY );
            mouseOneClick( mainObj.robot );
            mainObj.robot.delay(appDelay);
            mainObj.robot.delay(appDelay);
            mainObj.robot.delay(appDelay);
            parseChars(mainObj.robot, linePassword);
            mainObj.robot.delay(appDelay);
            oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );
            System.out.println( "signin password : " + linePassword); 

            // normal screen ? 
            mouseDelayMove( mainObj.robot, fscPosX, fscPosY );
            mouseOneClick( mainObj.robot );
            while(true) {
                Color color = mainObj.robot.getPixelColor(fscPosX, fscPosY);
                mainObj.robot.delay(100);
                int red = color.getRed();
                int green = color.getGreen();
                int blue = color.getBlue();
                if( 
                    ( red > 240  ) &&
                    ( green > 240  ) &&
                    ( blue > 240  ) 
                    ) {
                        break; 
                }
                else {
                    // auto fail
                    mainObj.robot.delay(100);
                    color = mainObj.robot.getPixelColor(fsePosX, fsePosY);
                    red = color.getRed();
                    green = color.getGreen();
                    blue = color.getBlue();
                    if( 
                        ( red >= 200  ) &&
                        ( green < 100  ) &&
                        ( blue < 100  ) 
                        ) {
                            status = 1;
                            break; 
                    }                
                    // auto fail
                    mainObj.robot.delay(100);
                    color = mainObj.robot.getPixelColor(red1PosX, red1PosY);
                    red = color.getRed();
                    green = color.getGreen();
                    blue = color.getBlue();
                    if( 
                        ( red >= 200  ) &&
                        ( green < 100  ) &&
                        ( blue < 100  ) 
                        ) {
                            status = 1;
                            break; 
                    }                
                }
            }
            // Set the Clover Configurator window position (0,0)
            moveMessageWindow();

            if ( status == 0  )
                System.out.println( "SUCCESSFUL"); 
            else  {
                System.out.println( "An error occurred during authentication"); 
                System.out.println( "FAILED"); 
            }
        }

        if ( status == 0  ) {
            // Action start
            // Go to Person item
            mouseDelayMove( mainObj.robot, rmPosX, rmPosY );
            // mouse click
            mouseOneClick( mainObj.robot );

            // delete menu
            if ( os == 0 )    
                mainObj.robot.keyPress(KeyEvent.VK_META);
            else
                mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
            mainObj.robot.delay(shiftDelay);
            mainObj.robot.keyPress( KeyEvent.VK_BACK_SPACE );
            mainObj.robot.keyRelease( KeyEvent.VK_BACK_SPACE );
            mainObj.robot.delay(shiftDelay);
            if ( os == 0 )    
                mainObj.robot.keyPress(KeyEvent.VK_META);
            else
                mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
            mainObj.robot.delay(endDelay);

            // Go to delete
            mouseDelayMove( mainObj.robot, riPosX, riPosY );
            // mouse click
            mouseOneClick( mainObj.robot );

            // Go to preference menu
            // first click
            if ( os == 0 )    
                mainObj.robot.keyPress(KeyEvent.VK_META);
            else
                mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
            mainObj.robot.delay(shiftDelay);
            mainObj.robot.keyPress( KeyEvent.VK_COMMA );
            mainObj.robot.keyRelease( KeyEvent.VK_COMMA );
            mainObj.robot.delay(shiftDelay);
            if ( os == 0 )    
                mainObj.robot.keyRelease(KeyEvent.VK_META);
            else
                mainObj.robot.keyRelease(KeyEvent.VK_WINDOWS);
            mainObj.robot.delay(endDelay);
            // set windows 0,0
            moveMessageWindow();

            // Go to Accounts menu
            mouseDelayMove( mainObj.robot, miPosX, miPosY );
            // mouse click
            mouseOneClick( mainObj.robot );

            // Go to Sign out
            mouseDelayMove( mainObj.robot, smPosX, smPosY );
            // mouse click
            mouseOneClick( mainObj.robot );
            
            // Go to Signout OK
            mouseDirectMove( mainObj.robot, pncPosX, pncPosY );
            // mouse click
            mouseOneClick( mainObj.robot );
                mainObj.robot.delay(appDelay);

            // show apple ID ?
            mouseDirectMove( mainObj.robot, eaPosX, eaPosY );
            while( true) {
                Color color = mainObj.robot.getPixelColor(eaPosX, eaPosY);
                int red = color.getRed();
                int green = color.getGreen();
                int blue = color.getBlue();
                if(
                        ( red > 240  ) &&
                        ( green > 240  ) &&
                        ( blue > 240  ) 
                ) {
                    break;
                }
            }

            // show password ?
            mouseDirectMove( mainObj.robot, psPosX, psPosY );
            int showPassword = 0;
            Color color = mainObj.robot.getPixelColor(psPosX, psPosY);
            int red = color.getRed();
            int green = color.getGreen();
            int blue = color.getBlue();
            if(
                    ( red > 240  ) &&
                    ( green > 240  ) &&
                    ( blue > 240  ) 
            ) {
                showPassword = 1; 
            }
//            showPassword = 0; 
            // not show
            if ( showPassword == 0 ) {
                System.out.println( "Passsword : NO ");
                // Go to Apple ID
                System.out.println( "Apple ID : " + lineAppleID); 
                parseChars(mainObj.robot, lineAppleID);
                oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );
                // ID ready ?
                while(true) {
                    color = mainObj.robot.getPixelColor(psPosX, psPosY);
                    red = color.getRed();
                    green = color.getGreen();
                    blue = color.getBlue();
                    if( 
                        ( red == psRed  ) &&
                        ( green == psGreen  ) &&
                        ( blue == psBlue  ) 
                    ) {
                        break; 
                    }
                }

                // Go to Password
                System.out.println( "Passsword : " + linePassword); 
                parseChars(mainObj.robot, linePassword);
                oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );

                // Password ready ?
                while(true) {
                    color = mainObj.robot.getPixelColor(psPosX, psPosY);
                    red = color.getRed();
                    green = color.getGreen();
                    blue = color.getBlue();
                    if(!( 
                        ( red == psRed  ) &&
                        ( green == psGreen  ) &&
                        ( blue == psBlue  ) 
                        )) {
                                break; 
                    }
                }
            }
            else {
                System.out.println( "Passsword : YES ");
                mainObj.robot.delay(appDelay);
                // Go to Apple ID
                System.out.println( "Apple ID : " + lineAppleID); 
                parseChars(mainObj.robot, lineAppleID);
                mainObj.robot.delay(appDelay);
                //  password
                mouseDirectMove( mainObj.robot, psPosX, psPosY );
                // mouse click
                mouseTwoClick( mainObj.robot );
                System.out.println( "Passsword : " + linePassword); 
                parseChars(mainObj.robot, linePassword);
                oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );

                mainObj.robot.delay(appDelay);

            }
            
            // end check ?
            mouseDirectMove( mainObj.robot, sokPosX, sokPosY );
            while( true) {
                // could not sign to iMessage ?
                mainObj.robot.delay(100);
                color = mainObj.robot.getPixelColor(yelPosX, yelPosX);
                red = color.getRed();
                green = color.getGreen();
                blue = color.getBlue();
                if(
                        ( red > 230  ) &&
                        ( green > 230  ) &&
                        ( blue > 230  ) 
                ) {
                    System.out.println( "FAILED" );
                    break;
                }
                // normal ok ?
                color = mainObj.robot.getPixelColor(sokPosX, sokPosY);
                red = color.getRed();
                green = color.getGreen();
                blue = color.getBlue();
                if(
                        ( red > 240  ) &&
                        ( green > 240  ) &&
                        ( blue > 240  ) 
                ) {
                    System.out.println( "SUCCESSFUL" );
                    break;
                }
            }

        }

        // Go to Accounts close
//        mouseDelayMove( mainObj.robot, sniPosX, sniPosY );
        // mouse click
//        mouseOneClick( mainObj.robot );
/*
        // Go to Recipient
        mouseDelayMove( mainObj.robot, siPosX, siPosY );
        // mouse click
        mouseOneClick( mainObj.robot );
        parseChars(mainObj.robot, sendMan);

        // Go to Message
        mouseDelayMove( mainObj.robot, bsniPosX, bsniPosY );
        // mouse click
        mouseOneClick( mainObj.robot );
        parseChars(mainObj.robot, sendMessage);

        oneKeyPress(mainObj.robot, KeyEvent.VK_ENTER );
*/
    }
}

class AppleScript {
    public void run(String name, String code) throws Throwable{
        PrintStream ps = new PrintStream(name);
        ps.println(code);
        ps.close();
        Runtime.getRuntime().exec("osascript " + name);
    }
 }