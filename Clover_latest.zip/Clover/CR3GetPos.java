/////////////////////////////////////////////////////////////////////////
//
//       Get the position for robot3
//
//  Date: 2018/09/18
//  Make: M.H team
//
//////////////////////////////////////////////////////////////////////////

import java.util.Scanner;
import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.lang.reflect.Field;
import java.awt.event.*;
import javax.swing.*;
import java.io.*; 
import java.util.concurrent.TimeUnit;
import java.util.UUID;
import java.io.File;
import java.io.PrintStream;

public class CR3GetPos {
    // File path
    public static String mainPath = "/Users/mac/Desktop";
    public static String posFileName = "/Clover/Position/CR3Pos.txt";
    public static String messgesApp = "/Applications/Messages.app";
    public static String testAppleID = "w636eiq@icloud.com";
    public static String testApplePass = "Rr112233";
    // OS
    // 0 - Mac, 1 - Windows
    public static int os = 0;
    // robot	
    Robot robot = null;
    // delay value
	static int shiftDelay = 50;
    static int endDelay = 200;
    static int appDelay = 1000;
    // persion item
    public static int rmPosX = 0; 
    public static int rmPosY = 0; 
    // delete
    public static int riPosX = 0; 
    public static int riPosY = 0; 
    // Accounts menu
    public static int miPosX = 0; 
    public static int miPosY = 0; 
    // Sign out
    public static int smPosX = 0; 
    public static int smPosY = 0; 
    // Sign out OK
    public static int pncPosX = 0; 
    public static int pncPosY = 0; 
    // Accounts close
    public static int sniPosX = 0; 
    public static int sniPosY = 0; 
    // password
    public static int psPosX = 0; 
    public static int psPosY = 0; 
    public static int psRed = 0; 
    public static int psGreen = 0; 
    public static int psBlue = 0; 
    // pos & color for execute conform
    public static int fsPosX = 0; 
    public static int fsPosY = 0; 
    public static int fsRed = 0; 
    public static int fsGreen = 0; 
    public static int fsBlue = 0; 
    // pos for first  signin password
    public static int fspPosX = 0; 
    public static int fspPosY = 0; 

    // first  signin successful confirm
    public static int fscPosX = 0; 
    public static int fscPosY = 0; 
    
    // first  signin error
    public static int fsePosX = 0; 
    public static int fsePosY = 0; 
    // enter apple id in first signin
    public static int eaPosX = 0; 
    public static int eaPosY = 0; 
    // enter red id pass incorrect  message  in first signin
    public static int red1PosX = 0; 
    public static int red1PosY = 0; 
    // enter auth error  message  in second signin
    // Could not sign in to iMessage
    public static int yelPosX = 0; 
    public static int yelPosY = 0; 
    public static int yelRed = 0; 
    public static int yelGreen = 0; 
    public static int yelBlue = 0; 
    // end signin ok
    public static int sokPosX = 0; 
    public static int sokPosY = 0; 

    public static void parseChars(Robot robot, String letter) {
        for (int i = 0; i < letter.length(); i ++) {
            char chary = letter.charAt(i);
            typeCharacter(robot, Character.toString(chary));
        }
    }

    public static void typeCharacter(Robot robot, String letter) {
        for ( int i = 0; i < letter.length(); i++ ) {
            char a_char = letter.charAt(0);
            if( Character.isLetterOrDigit( a_char ) )
            {
                if(a_char >= '0' && a_char <= '9') {
                    oneKeyPress(robot, a_char );
                }
                else if(a_char >= 'A' && a_char <= 'Z') {
                    twoKeyPress(robot, KeyEvent.VK_SHIFT, a_char );
                }
                else if(a_char >= 'a' && a_char <= 'z') {
                    a_char -= 0x20;
                    oneKeyPress(robot, a_char );
                }                
            }
            else if ( a_char == '!' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_1 );
            }
            else if ( a_char == '@' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_2 );
            }
            else if ( a_char == '#' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_3 );
            }
            else if ( a_char == '$' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_4 );
            }
            else if ( a_char == '%' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_5 );
            }
            else if ( a_char == '^' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_6 );
            }
            else if ( a_char == '&' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_7 );
            }
            else if ( a_char == '*' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_8 );
            }
            else if ( a_char == '(' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_9 );
            }
            else if ( a_char == ')' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_0 );
            }
            else if ( a_char == '_' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '-' );
            }
            else if ( a_char == '+' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '=' );
            }
            else if ( a_char == '{' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '[' );
            }
            else if ( a_char == '}' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, ']' );
            }
            else if ( a_char == '<' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, KeyEvent.VK_COMMA );
            }
            else if ( a_char == '>' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '.' );
            }
            else if ( a_char == '?' ) {
                twoKeyPress(robot, KeyEvent.VK_SHIFT, '/' );
            }
            else if( a_char == ',' )  {
                oneKeyPress(robot, KeyEvent.VK_COMMA );
            }
            else  {
                oneKeyPress(robot, a_char );
            }
        }
    }

    ////////////////////////////   Mouse move    ////////////////////////
    public static void MouseMoveThread(  Robot _robot,  int endX, int endY,
        int numberOfIterations, long timeToSleep ) {
        int startX;
        int startY;
        int currentX;
        int currentY;
        int xAmount;
        int yAmount;
        int xAmountPerIteration;
        int yAmountPerIteration;
                    
            Robot robot =  _robot;
            Point startLocation = MouseInfo.getPointerInfo().getLocation();
            startX = startLocation.x;
            startY = startLocation.y;
            if ( endX > startX )
                xAmount = endX - startX;
            else
                xAmount = startX - endX;
            
            if ( endY > startY )
                yAmount = endY - startY;
            else
                yAmount = startY - endY;

            currentX = startX;
            currentY = startY;

            xAmountPerIteration = xAmount / numberOfIterations;
            yAmountPerIteration = yAmount / numberOfIterations;

            if( endX >= startX ) {
                if ( endY >= startY ) {
                    while ( currentX < endX &&
                            currentY < endY ) {

                        currentX += xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX < endX &&
                            currentY > endY ) {

                        currentX += xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
            else {
                if ( endY >= startY ) {
                    while ( currentX > endX &&
                            currentY < endY ) {

                        currentX -= xAmountPerIteration;
                        currentY += yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
                else {
                    while ( currentX > endX &&
                            currentY > endY ) {

                        currentX -= xAmountPerIteration;
                        currentY -= yAmountPerIteration;

                        robot.mouseMove( currentX, currentY );
                        robot.delay(2);
                    }
                }
            }
    }
    /////////////////////////////////////////////////////////////////////

    // Write the position for robot
    public static void posFileSave() {
        try (PrintWriter out = new PrintWriter( mainPath + posFileName )) {
            String textStr = Integer.toString(rmPosX);
            out.println(textStr);
            textStr = Integer.toString(rmPosY);
            out.println(textStr);
            textStr = Integer.toString(riPosX);
            out.println(textStr);
            textStr = Integer.toString(riPosY);
            out.println(textStr);
            textStr = Integer.toString(miPosX);
            out.println(textStr);
            textStr = Integer.toString(miPosY);
            out.println(textStr);
            textStr = Integer.toString(smPosX);
            out.println(textStr);
            textStr = Integer.toString(smPosY);
            out.println(textStr);
            textStr = Integer.toString(pncPosX);
            out.println(textStr);
            textStr = Integer.toString(pncPosY);
            out.println(textStr);
            textStr = Integer.toString(sniPosX);
            out.println(textStr);
            textStr = Integer.toString(sniPosY);
            out.println(textStr);
            textStr = Integer.toString(psPosX);
            out.println(textStr);
            textStr = Integer.toString(psPosY);
            out.println(textStr);
            textStr = Integer.toString(psRed);
            out.println(textStr);
            textStr = Integer.toString(psGreen);
            out.println(textStr);
            textStr = Integer.toString(psBlue);
            out.println(textStr);
            textStr = Integer.toString(fsPosX);
            out.println(textStr);
            textStr = Integer.toString(fsPosY);
            out.println(textStr);
            textStr = Integer.toString(fsRed);
            out.println(textStr);
            textStr = Integer.toString(fsGreen);
            out.println(textStr);
            textStr = Integer.toString(fsBlue);
            out.println(textStr);

            textStr = Integer.toString(fspPosX);
            out.println(textStr);
            textStr = Integer.toString(fspPosY);
            out.println(textStr);
            textStr = Integer.toString(fscPosX);
            out.println(textStr);
            textStr = Integer.toString(fscPosY);
            out.println(textStr);
            textStr = Integer.toString(fsePosX);
            out.println(textStr);
            textStr = Integer.toString(fsePosY);
            out.println(textStr);
            textStr = Integer.toString(eaPosX);
            out.println(textStr);
            textStr = Integer.toString(eaPosY);
            out.println(textStr);
            textStr = Integer.toString(red1PosX);
            out.println(textStr);
            textStr = Integer.toString(red1PosY);
            out.println(textStr);
            textStr = Integer.toString(yelPosX);
            out.println(textStr);
            textStr = Integer.toString(yelPosY);
            out.println(textStr);
            textStr = Integer.toString(yelRed);
            out.println(textStr);
            textStr = Integer.toString(yelGreen);
            out.println(textStr);
            textStr = Integer.toString(yelBlue);
            out.println(textStr);
            textStr = Integer.toString(sokPosX);
            out.println(textStr);
            textStr = Integer.toString(sokPosY);
            out.println(textStr);
        }
        catch (IOException e) {
//            e.printStackTrace();
        }
    }

    // Read the position for robot
    public static void posFileRead() {
        File f = new File( mainPath + posFileName );
        if( !(f.exists() && !f.isDirectory()) ) { 
            return;
        }
        try {
            BufferedReader br = new BufferedReader(new FileReader( mainPath + posFileName ));
            try {
                StringBuilder sb = new StringBuilder();
                String line = br.readLine();
                rmPosX = Integer.parseInt(line);
                int i = 0;
                while (line != null) {
                    line = br.readLine();
                    if ( i == 0 ) {
                        rmPosY = Integer.parseInt(line);
                    }
                    else if ( i == 1 ) {
                        riPosX = Integer.parseInt(line);
                    }
                    else if ( i == 2 ) {
                        riPosY = Integer.parseInt(line);
                    }
                    else if ( i == 3 ) {
                        miPosX = Integer.parseInt(line);
                    }
                    else if ( i == 4 ) {
                        miPosY = Integer.parseInt(line);
                    }
                    else if ( i == 5 ) {
                        smPosX = Integer.parseInt(line);
                    }
                    else if ( i == 6 ) {
                        smPosY = Integer.parseInt(line);
                    }
                    else if ( i == 7 ) {
                        pncPosX = Integer.parseInt(line);
                    }
                    else if ( i == 8 ) {
                        pncPosY = Integer.parseInt(line);
                    }
                    else if ( i == 9 ) {
                        sniPosX = Integer.parseInt(line);
                    }
                    else if ( i == 10 ) {
                        sniPosY = Integer.parseInt(line);
                    }
                    else if ( i == 11 ) {
                        psPosX = Integer.parseInt(line);
                    }
                    else if ( i == 12 ) {
                        psPosY = Integer.parseInt(line);
                    }
                    else if ( i == 13 ) {
                        psRed = Integer.parseInt(line);
                    }
                    else if ( i == 14 ) {
                        psGreen = Integer.parseInt(line);
                    }
                    else if ( i == 15 ) {
                        psBlue = Integer.parseInt(line);
                    }

                    else if ( i == 16 ) {
                        fsPosX = Integer.parseInt(line);
                    }
                    else if ( i == 17 ) {
                        fsPosY = Integer.parseInt(line);
                    }
                    else if ( i == 18 ) {
                        fsRed = Integer.parseInt(line);
                    }
                    else if ( i == 19 ) {
                        fsGreen = Integer.parseInt(line);
                    }
                    else if ( i == 20 ) {
                        fsBlue = Integer.parseInt(line);
                    }
                    else if ( i == 21 ) {
                        fspPosX = Integer.parseInt(line);
                    }
                    else if ( i == 22 ) {
                        fspPosY = Integer.parseInt(line);
                    }
                    else if ( i == 23 ) {
                        fscPosX = Integer.parseInt(line);
                    }
                    else if ( i == 24 ) {
                        fscPosY = Integer.parseInt(line);
                    }
                    else if ( i == 25 ) {
                        fsePosX = Integer.parseInt(line);
                    }
                    else if ( i == 26 ) {
                        fsePosY = Integer.parseInt(line);
                    }
                    else if ( i == 27 ) {
                        eaPosX = Integer.parseInt(line);
                    }
                    else if ( i == 28 ) {
                        eaPosY = Integer.parseInt(line);
                    }
                    else if ( i == 29 ) {
                        red1PosX = Integer.parseInt(line);
                    }
                    else if ( i == 30 ) {
                        red1PosY = Integer.parseInt(line);
                    }
                    else if ( i == 31 ) {
                        yelPosX = Integer.parseInt(line);
                    }
                    else if ( i == 32 ) {
                        yelPosY = Integer.parseInt(line);
                    }
                    else if ( i == 33 ) {
                        yelRed = Integer.parseInt(line);
                    }
                    else if ( i == 34 ) {
                        yelGreen = Integer.parseInt(line);
                    }
                    else if ( i == 35 ) {
                        yelBlue = Integer.parseInt(line);
                    }
                    else if ( i == 36 ) {
                        sokPosX = Integer.parseInt(line);
                    }
                    else if ( i == 37 ) {
                        sokPosY = Integer.parseInt(line);
                    }
                    i++;
                } 
                br.close();
            } catch (IOException e) {
            }	
        } catch (FileNotFoundException e) {
        }

    }
    // move message window (  0, 0 )
    public static void moveMessageWindow() throws Throwable {

            // Set the Clover Configurator window position (0,0)
            String code = "";
            code += "tell application \"System Events\" to tell process \"Messages\"\n";
            code += "    tell application \"Messages\" to activate\n";
            code += "    tell front window to set position to {0, 0}\n";
            code += "end tell\n";
            new AppleScript().run("move_win.as", code);
            Thread.sleep(appDelay);
    }
    
    // mouse one click
    public static void mouseOneClick(Robot robot) {
        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);
        robot.delay(endDelay);
    }

    // mouse two click
    public static void mouseTwoClick(Robot robot) {
        mouseOneClick(robot);
        mouseOneClick(robot);
    }

    // mouse direct move
    public static void mouseDirectMove(Robot robot, int x, int y ) {
        robot.mouseMove( x, y );
        robot.delay(2);
    }

    // mouse delay move
    public static void mouseDelayMove(Robot robot, int x, int y ) {
        MouseMoveThread( robot, x, y, 100, 5 );
        robot.mouseMove( x, y );
        robot.delay(2);
    }

     // one key press
    public static void oneKeyPress(Robot robot, int keyCode ) {
        robot.keyPress( keyCode );
        robot.keyRelease( keyCode );
        robot.delay(endDelay);
    }

     // two key press
     public static void twoKeyPress(Robot robot, int keyCode1, int keyCode2 ) {
        robot.keyPress( keyCode1 );
        robot.delay( shiftDelay );
        robot.keyPress( keyCode2 );
        robot.keyRelease( keyCode2 );
        robot.delay( shiftDelay );
        robot.keyRelease( keyCode1 );
        robot.delay( endDelay );
    }

	public static void main(String[] args) throws Throwable {
/*
        // execute Message app 
        try {
            Runtime runtime = Runtime.getRuntime();
            String s= "open " + messgesApp;
            Process proc = runtime.exec(s);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // Set the Clover Configurator window position (0,0)
        moveMessageWindow();
*/
        CR3GetPos mainObj = new CR3GetPos();
        // make robot
        try { 
            mainObj.robot = new Robot(); 
        }
        catch (Exception ex) { 
            ex.printStackTrace(); 
        }        

        Scanner keyboard = new Scanner(System.in);
        boolean exit = false;
        
        // If pos file, read
        posFileRead();

        while (!exit) {
            System.out.println("-------------------------");
            System.out.println("Enter command");
            // Person item
            if ( rmPosX == 0 )
                System.out.println("u to person item"); 
            else {
                String str = "u to person item - x:";
                String add = Integer.toString(rmPosX);
                str += add;
                str += " y:";
                add = Integer.toString(rmPosY);
                str += add;
                System.out.println(str);
            }
            // Delete
            if ( riPosX == 0 )
                System.out.println("r to delete item"); 
            else {
                String str = "r to delete item - x:";
                String add = Integer.toString(riPosX);
                str += add;
                str += " y:";
                add = Integer.toString(riPosY);
                str += add;
                System.out.println(str);
            }
            // Accounts menu
            if ( miPosX == 0 )
                System.out.println("m to Accounts menu"); 
            else {
                String str = "m to Accounts menu - x:";
                String add = Integer.toString(miPosX);
                str += add;
                str += " y:";
                add = Integer.toString(miPosY);
                str += add;
                System.out.println(str);
            }
            // Sign out
            if ( smPosX == 0 )
                System.out.println("s to Sign out"); 
            else {
                String str = "s to Sign out - x:";
                String add = Integer.toString(smPosX);
                str += add;
                str += " y:";
                add = Integer.toString(smPosY);
                str += add;
                System.out.println(str);
            }
            // Sign out OK
            if ( pncPosX == 0 )
                System.out.println("c to Sign out OK"); 
            else {
                String str = "c to Sign out OK - x:";
                String add = Integer.toString(pncPosX);
                str += add;
                str += " y:";
                add = Integer.toString(pncPosY);
                str += add;
                System.out.println(str);
            }
            // Accounts close
            if ( sniPosX == 0 )
                System.out.println("n to Accounts close"); 
            else {
                String str = "n to Accounts close - x:";
                String add = Integer.toString(sniPosX);
                str += add;
                str += " y:";
                add = Integer.toString(sniPosY);
                str += add;
                System.out.println(str);
            }
            // password
            if ( psPosX == 0 )
                System.out.println("i to password"); 
            else {
                String str = "i to password - x:";
                String add = Integer.toString(psPosX);
                str += add;
                str += " y:";
                add = Integer.toString(psPosY);
                str += add;
                str += " R:";
                add = Integer.toString(psRed);
                str += add;
                str += " G:";
                add = Integer.toString(psGreen);
                str += add;
                str += " B:";
                add = Integer.toString(psBlue);
                str += add;
                System.out.println(str);
            }
            // pos for execute confirm 
            if ( fsPosX == 0 )
                System.out.println("1 to first screen"); 
            else {
                String str = "1 to first screen - x:";
                String add = Integer.toString(fsPosX);
                str += add;
                str += " y:";
                add = Integer.toString(fsPosY);
                str += add;
                str += " R:";
                add = Integer.toString(fsRed);
                str += add;
                str += " G:";
                add = Integer.toString(fsGreen);
                str += add;
                str += " B:";
                add = Integer.toString(fsBlue);
                str += add;
                System.out.println(str);
            }
            // first signin password
            if ( fspPosX == 0 )
                System.out.println("2 to signin password "); 
            else {
                String str = "2 to signin password  - x:";
                String add = Integer.toString(fspPosX);
                str += add;
                str += " y:";
                add = Integer.toString(fspPosY);
                str += add;
                System.out.println(str);
            }
            // first  signin successful confirm
            if ( fscPosX == 0 )
                System.out.println("3 to signin successful confirm "); 
            else {
                String str = "3 to signin successful confirm  - x:";
                String add = Integer.toString(fscPosX);
                str += add;
                str += " y:";
                add = Integer.toString(fscPosY);
                str += add;
                System.out.println(str);
            }
            // first  signin error
            if ( fsePosX == 0 )
                System.out.println("4 to signin error "); 
            else {
                String str = "4 to signin error  - x:";
                String add = Integer.toString(fsePosX);
                str += add;
                str += " y:";
                add = Integer.toString(fsePosY);
                str += add;
                System.out.println(str);
            }
            // enter apple idr
            if ( eaPosX == 0 )
                System.out.println("5 to enter apple id "); 
            else {
                String str = "5 to enter apple id  - x:";
                String add = Integer.toString(eaPosX);
                str += add;
                str += " y:";
                add = Integer.toString(eaPosY);
                str += add;
                System.out.println(str);
            }
            // enter pass incorrect red text 
            if ( red1PosX == 0 )
                System.out.println("6 to incorrect red text "); 
            else {
                String str = "6 to incorrect red text  - x:";
                String add = Integer.toString(red1PosX);
                str += add;
                str += " y:";
                add = Integer.toString(red1PosY);
                str += add;
                System.out.println(str);
            }
            // enter could not sign 
            if ( yelPosX == 0 )
                System.out.println("7 to could not sign"); 
            else {
                String str = "7 to could not sign x:";
                String add = Integer.toString(yelPosX);
                str += add;
                str += " y:";
                add = Integer.toString(yelPosY);
                str += add;
                str += " R:";
                add = Integer.toString(yelRed);
                str += add;
                str += " G:";
                add = Integer.toString(yelGreen);
                str += add;
                str += " B:";
                add = Integer.toString(yelBlue);
                str += add;
                System.out.println(str);
            }
            // enter end signin ok 
            if ( sokPosX == 0 )
                System.out.println("8 to end signin ok "); 
            else {
                String str = "8 to end signin ok  - x:";
                String add = Integer.toString(sokPosX);
                str += add;
                str += " y:";
                add = Integer.toString(sokPosY);
                str += add;
                System.out.println(str);
            }

            System.out.println("t to test"); 
            System.out.println("e to save"); 
            System.out.println("q to exit"); 
            System.out.println("-------------------------");

            String input = keyboard.nextLine();
            if(input != null) {
                // Quit
                if ("q".equals(input)) {
                    exit = true;
                } 
                // Save
                else if ("e".equals(input)) {
                    posFileSave();
                } 
                // Test
                else if ("t".equals(input)) {
//////////////////////////////    test     ///////////////////////////////////////////////
                    // Go to Person item
                    mouseDelayMove( mainObj.robot, rmPosX, rmPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );
                    
                    // delete menu
                    if ( os == 0 )    
                        mainObj.robot.keyPress(KeyEvent.VK_META);
                    else
                        mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
                    mainObj.robot.delay(shiftDelay);
                    mainObj.robot.keyPress( KeyEvent.VK_BACK_SPACE );
                    mainObj.robot.keyRelease( KeyEvent.VK_BACK_SPACE );
                    mainObj.robot.delay(shiftDelay);
                    if ( os == 0 )    
                        mainObj.robot.keyPress(KeyEvent.VK_META);
                    else
                        mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
                    mainObj.robot.delay(endDelay);
                    
                    // Go to delete
                    mouseDelayMove( mainObj.robot, riPosX, riPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );
                    
                    // Go to preference menu
                    // first click
                    if ( os == 0 )    
                        mainObj.robot.keyPress(KeyEvent.VK_META);
                    else
                        mainObj.robot.keyPress(KeyEvent.VK_WINDOWS);
                    mainObj.robot.delay(shiftDelay);
                    mainObj.robot.keyPress( KeyEvent.VK_COMMA );
                    mainObj.robot.keyRelease( KeyEvent.VK_COMMA );
                    mainObj.robot.delay(shiftDelay);
                    if ( os == 0 )    
                        mainObj.robot.keyRelease(KeyEvent.VK_META);
                    else
                        mainObj.robot.keyRelease(KeyEvent.VK_WINDOWS);
                    mainObj.robot.delay(endDelay);

                    moveMessageWindow();

                    // Go to Accounts menu
                    mouseDelayMove( mainObj.robot, miPosX, miPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );

                    // Go to Sign out
                    mouseDelayMove( mainObj.robot, smPosX, smPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );

                    // Go to Signout OK
                    mouseDirectMove( mainObj.robot, pncPosX, pncPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );

                    // Go to Apple ID
                    mainObj.robot.delay(appDelay);
                    mainObj.robot.delay(appDelay);
                    parseChars(mainObj.robot, testAppleID);
                    mainObj.robot.keyPress( KeyEvent.VK_ENTER );
                    mainObj.robot.keyRelease( KeyEvent.VK_ENTER );
                    mainObj.robot.delay(shiftDelay);
                    mainObj.robot.delay(appDelay);
                    mainObj.robot.delay(appDelay);
                    mainObj.robot.delay(appDelay);

                    // Go to Password
                    parseChars(mainObj.robot, testApplePass);
                    mainObj.robot.keyPress( KeyEvent.VK_ENTER );
                    mainObj.robot.keyRelease( KeyEvent.VK_ENTER );
                    mainObj.robot.delay(appDelay);
                    mainObj.robot.delay(appDelay);
                    mainObj.robot.delay(appDelay);

                    // Go to Accounts close
                    mouseDelayMove( mainObj.robot, sniPosX, sniPosY );
                    // mouse click
                    mouseOneClick( mainObj.robot );

//////////////////////////////////////////////////////////////////////////////////////////

                }
                    // Person Item
                else if ("u".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    rmPosX = startLocation.x;
                    rmPosY = startLocation.y;
                } 
                // delete
                else if ("r".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    riPosX = startLocation.x;
                    riPosY = startLocation.y;
                } 
                // Accounts menu
                else if ("m".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    miPosX = startLocation.x;
                    miPosY = startLocation.y;
                } 
                // Sign Out
                else if ("s".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    smPosX = startLocation.x;
                    smPosY = startLocation.y;
                } 

                // Sign out OK
                else if ("c".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    pncPosX = startLocation.x;
                    pncPosY = startLocation.y;
                } 
                // Accounts close
                else if ("n".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    sniPosX = startLocation.x;
                    sniPosY = startLocation.y;
                } 
                // password
                else if ("i".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    psPosX = startLocation.x;
                    psPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(psPosX, psPosY);
                    psRed = color.getRed();
                    psGreen = color.getGreen();
                    psBlue = color.getBlue();
                } 
                // first screen
                else if ("1".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    fsPosX = startLocation.x;
                    fsPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(psPosX, psPosY);
                    fsRed = color.getRed();
                    fsGreen = color.getGreen();
                    fsBlue = color.getBlue();
                } 
                // first  signin password
                else if ("2".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    fspPosX = startLocation.x;
                    fspPosY = startLocation.y;
                } 
                // signin successful confirm
                else if ("3".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    fscPosX = startLocation.x;
                    fscPosY = startLocation.y;
                } 
                // signin error
                else if ("4".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    fsePosX = startLocation.x;
                    fsePosY = startLocation.y;
                } 
                // enter apple id
                else if ("5".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    eaPosX = startLocation.x;
                    eaPosY = startLocation.y;
                } 
                // enter incorrect red text
                else if ("6".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    red1PosX = startLocation.x;
                    red1PosY = startLocation.y;

                    Color color = mainObj.robot.getPixelColor(red1PosX, red1PosY);
                    int red = color.getRed();
                    int green = color.getGreen();
                    int blue = color.getBlue();
                    System.out.println(red + ":" + green + ":" + blue);
                }
                // Could not sign in
                else if ("7".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    yelPosX = startLocation.x;
                    yelPosY = startLocation.y;
                    Color color = mainObj.robot.getPixelColor(yelPosX, yelPosY);
                    yelRed = color.getRed();
                    yelGreen = color.getGreen();
                    yelBlue = color.getBlue();
                } 
                // end signin ok
                else if ("8".equals(input)) {
                    Point startLocation = MouseInfo.getPointerInfo().getLocation();
                    sokPosX = startLocation.x;
                    sokPosY = startLocation.y;
                }
                else {
                    System.out.println("Bad command");
                }
            }
        }
        keyboard.close();
    }
}

class AppleScript {
    public void run(String name, String code) throws Throwable{
        PrintStream ps = new PrintStream(name);
        ps.println(code);
        ps.close();
        Runtime.getRuntime().exec("osascript " + name);
    }
 }